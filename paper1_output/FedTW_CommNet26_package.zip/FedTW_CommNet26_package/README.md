# FedTW — CommNet'26 submission package

**FedTW: Target-Wise Label-Shift Correction for Federated Multi-Target Cloud Workload Forecasting**
Thanoon Y. Mohammed, Ahmad F. AL-allaf, M. R. Mouhamed

| Folder | Content |
|---|---|
| `latex/` | `FedTW_CommNet26.tex` (IEEEtran conference class, 10 pt, two columns, US letter), `figures/` (vector PDF), and the compiled `FedTW_CommNet26.pdf` (7 pages) |
| `office/` | `FedTW_CommNet26.docx` — the same paper as an editable Word document (native Word equations) |
| `reproducibility/` | data, code, per-seed results and generated tables/figures; see `reproducibility/README.md` |

## Compile the LaTeX version
```bash
cd latex
pdflatex FedTW_CommNet26.tex
pdflatex FedTW_CommNet26.tex
```
Needs a standard TeX Live installation (IEEEtran, algorithm/algpseudocode, booktabs, balance, microtype).
The bibliography is embedded in the .tex file, so BibTeX is not needed.

## Reproduce the results
```bash
cd reproducibility/code
python3 smoke_test.py      # installation check (~2 min)
./make_outputs.sh          # all tables and figures from the stored results (~1 min, no training)
```
