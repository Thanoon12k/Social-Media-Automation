"""Retrains one published configuration and compares it with the stored result.
usage: python3 verify_rerun.py [trace] [regime] [method]   (default: alibaba LS-dur-0.1 fedtw)
Takes about 5 minutes on 4 CPU cores for a ten-seed configuration."""
import json, os, sys
import numpy as np
import fedcloud as fc
import run_grid

d = sys.argv[1] if len(sys.argv) > 1 else "alibaba"
s = sys.argv[2] if len(sys.argv) > 2 else "LS-dur-0.1"
m = sys.argv[3] if len(sys.argv) > 3 else "fedtw"
stored = json.load(open(os.path.join(run_grid.OUT, d, f"{s}__{m}.json")))
seeds = sorted({x["seed"] for x in stored["results"]})
r = fc.run(fc.load(d), "IID" if s == "CENTRAL" else s, seeds, stored["cfg"])
worst = 0.0
for a, b in zip(stored["results"], r["results"]):
    for t in fc.TARGETS:
        worst = max(worst, abs(a["metrics"][t]["R2"] - b["metrics"][t]["R2"]))
best = lambda res: {t: float(np.mean([x["metrics"][t]["R2"] for x in res if x["ckpt"] == "best"])) for t in fc.TARGETS}
print("stored   :", {k: round(v, 3) for k, v in best(stored["results"]).items()})
print("re-run   :", {k: round(v, 3) for k, v in best(r["results"]).items()})
print(f"largest per-seed R2 difference: {worst:.4f} points")
