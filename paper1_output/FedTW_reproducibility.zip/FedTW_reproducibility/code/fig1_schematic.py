"""Fig. 1: FedTW workflow schematic."""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

FIG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "outputs", "figures")
plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 8.5})
fig, ax = plt.subplots(figsize=(8.6, 4.2))
ax.set_xlim(0, 100); ax.set_ylim(0, 50); ax.axis("off")


def box(x, y, w, h, text, fc="#f2f2f2", ec="#555555", fs=8.5, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2", fc=fc, ec=ec, lw=0.9))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, weight="bold" if bold else None, wrap=True)


def arrow(x1, y1, x2, y2, text=None, style="-|>", ls="-"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=10, lw=1.0,
                                 color="#333333", linestyle=ls))
    if text:
        ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 1.2, text, ha="center", va="bottom", fontsize=7.5, style="italic")


# clients
rng = np.random.default_rng(3)
cols = ["#2b83ba", "#1a9850", "#d08c2b"]
for i, (y, lab) in enumerate([(35, "Site 1: short jobs"), (20, "Site 2: medium jobs"), (5, "Site K: long jobs")]):
    box(1, y, 25, 10, "", fc="#ffffff")
    ax.text(13.5, y + 8.6, lab, ha="center", fontsize=8, weight="bold")
    # mini histogram of duration bins
    h = np.exp(-0.5 * ((np.arange(10) - [2, 5, 8][i]) / 1.2) ** 2)
    h = h / h.max() * 5
    for q in range(10):
        ax.add_patch(plt.Rectangle((3 + q * 1.1, y + 1.5), 0.9, h[q], color=cols[0], alpha=0.85))
    ax.text(18.5, y + 3.5, "duration\nhistogram", fontsize=6.5, ha="left", va="center", color="#444444")
ax.text(13.5, 16.3, "...", ha="center", fontsize=12, rotation=90)

# server
box(39, 30, 24, 15, "Server\n(1) sum client histograms\ninto global bin distribution p", fc="#e8f1fa", ec="#2b83ba")
box(39, 5, 24, 15, "Server\n(4) sample-weighted FedAvg\nor FedAdam aggregation", fc="#e8f1fa", ec="#2b83ba")
# client side training
box(74, 30, 25, 15, "Client k\n(2) weights per target j:\nω = min(p / πₖ , c)\n(renormalised, one-off)", fc="#eaf6ee", ec="#1a9850")
box(74, 5, 25, 15, "Client k\n(3) local steps on\nΣⱼ ωⱼ · |fⱼ(x) − yⱼ|", fc="#eaf6ee", ec="#1a9850")

arrow(27, 42, 38.5, 40, "3Q counts, once")
arrow(27, 26, 38.5, 36)
arrow(27, 10, 38.5, 33)
arrow(63.5, 40, 73.5, 40, "p (once)")
arrow(86.5, 29.5, 86.5, 20.5)
arrow(73.5, 10, 63.5, 10, "model update")
arrow(51, 20.5, 51, 29.5, style="<|-|>", ls=":")
ax.text(52.5, 25, "every\nround", fontsize=7, style="italic", va="center")
ax.annotate("", xy=(74, 16), xytext=(63.5, 16), arrowprops=dict(arrowstyle="-|>", lw=1.0, color="#333333"))
ax.text(68.5, 17, "global model", fontsize=7.5, style="italic", ha="center")
fig.savefig(os.path.join(FIG, "fig1_fedtw.png"), dpi=300, bbox_inches="tight")
print("ok")
