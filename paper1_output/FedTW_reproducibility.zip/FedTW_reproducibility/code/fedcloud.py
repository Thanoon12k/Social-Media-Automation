"""Batched federated-learning engine for multi-target cloud workload forecasting.

Every (seed, client) pair is one slice of a stacked parameter tensor, so a whole
federation for all seeds trains as one batched model on CPU.

Data protocol (identical for every method, scenario and seed)
------------------------------------------------------------
* jobs sorted by start time; log1p + median/IQR scaling fitted on the training
  period only;
* one global chronological cut: 72 % train, 8 % validation, 20 % test;
* a sample = 24 consecutive jobs -> the next job (duration, CPU, memory);
  samples are built inside one period, so no window crosses a split boundary;
* only TRAINING samples are distributed to clients by the scenario; validation
  samples are used for checkpoint selection (the pooled validation MAE equals the
  sample-weighted federated validation loss), test samples are never used for
  any decision.
"""
import math, time, os
import numpy as np
import pandas as pd
import torch

torch.set_num_threads(int(os.environ.get("FC_THREADS", "4")))
SEQ = 24
TARGETS = ["duration", "real_cpu_avg", "real_mem_avg"]
DATA_DIR = os.environ.get("FC_DATA", os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data"))
FILES = {"alibaba": "cleaned_alibaba_10.csv", "in2p3": "cleaned_in2p3_70.csv"}
NBINS = 10


# ----------------------------------------------------------------------------
# data
# ----------------------------------------------------------------------------
def load(name):
    df = pd.read_csv(os.path.join(DATA_DIR, FILES[name]))
    df = df.sort_values("start_ts", kind="stable").reset_index(drop=True)
    raw = df[TARGETS].values.astype(np.float64)
    lg = np.log1p(raw)
    N = len(df)
    n_tr, n_va = int(0.72 * N), int(0.80 * N)
    med = np.median(lg[:n_tr], 0)
    iqr = np.percentile(lg[:n_tr], 75, 0) - np.percentile(lg[:n_tr], 25, 0)
    z = ((lg - med) / iqr).astype(np.float32)
    bounds = [(0, n_tr), (n_tr, n_va), (n_va, N)]
    W = []
    for a, b in bounds:                      # windows never cross a boundary
        rows = np.arange(a, b)
        W.append(np.lib.stride_tricks.sliding_window_view(rows, SEQ + 1).copy())
    ds = dict(name=name, z=z, raw=raw, med=med, iqr=iqr, N=N, n_tr=n_tr, n_va=n_va,
              Wtr=W[0], Wva=W[1], Wte=W[2])
    # target quantile bins of every training sample (edges from training period)
    ytr = raw[W[0][:, SEQ]]
    ds["edges"] = [np.quantile(raw[:n_tr, j], np.linspace(0, 1, NBINS + 1)[1:-1]) for j in range(3)]
    ds["bins"] = np.stack([np.searchsorted(ds["edges"][j], ytr[:, j], side="right") for j in range(3)], 1)
    return ds


# ----------------------------------------------------------------------------
# scenarios: client id of every training sample
# ----------------------------------------------------------------------------
SCENARIOS = {
    "IID":          dict(kind="iid"),
    "QTY":          dict(kind="quantity", alpha=0.5),
    "TEMP":         dict(kind="temporal"),
    "LS-dur-1.0":   dict(kind="label", target="duration", alpha=1.0),
    "LS-dur-0.3":   dict(kind="label", target="duration", alpha=0.3),
    "LS-dur-0.1":   dict(kind="label", target="duration", alpha=0.1),
    "LS-cpu-0.1":   dict(kind="label", target="real_cpu_avg", alpha=0.1),
    "LS-mem-0.1":   dict(kind="label", target="real_mem_avg", alpha=0.1),
    "BAND-dur":     dict(kind="band", target="duration", s=0.8),
    "SYS":          dict(kind="sys"),
    "PART":         dict(kind="partial"),
}


def partition(ds, scen, seed, K=20):
    rng = np.random.default_rng(10_000 + seed)
    n = len(ds["Wtr"])
    kind = scen["kind"]
    if kind in ("iid", "sys", "partial"):
        return rng.permutation(np.arange(n) % K)
    if kind == "quantity":
        p = rng.dirichlet([scen["alpha"]] * K)
        p = np.maximum(p, 0.002); p /= p.sum()
        return rng.choice(K, n, p=p)
    if kind == "temporal":
        return np.minimum((np.arange(n) * K) // n, K - 1)
    if kind == "label":          # Dirichlet label-distribution skew over target bins
        b = ds["bins"][:, TARGETS.index(scen["target"])]
        cid = np.empty(n, np.int64)
        for c in range(NBINS):
            idx = np.where(b == c)[0]
            q = rng.dirichlet([scen["alpha"]] * K)
            cid[idx] = rng.choice(K, len(idx), p=q)
        return cid
    if kind == "band":           # sorted target bands + (1-s) IID share (previous S4)
        j = TARGETS.index(scen["target"])
        y = ds["raw"][ds["Wtr"][:, SEQ], j]
        cid = np.empty(n, np.int64)
        sk = rng.random(n) < scen["s"]
        idx = np.where(sk)[0]
        idx = idx[np.argsort(y[idx], kind="stable")]
        cid[idx] = np.minimum((np.arange(len(idx)) * K) // len(idx), K - 1)
        cid[~sk] = rng.permutation(np.arange((~sk).sum()) % K)
        return cid
    raise ValueError(kind)


def client_js(ds, cid, K):
    """per-client, per-target Jensen-Shannon divergence (bits) to the global histogram"""
    out = np.zeros((K, 3))
    for j in range(3):
        b = ds["bins"][:, j]
        g = np.bincount(b, minlength=NBINS) / len(b)
        for k in range(K):
            bk = b[cid == k]
            if len(bk) == 0:
                continue
            p = np.bincount(bk, minlength=NBINS) / len(bk)
            m = 0.5 * (p + g)
            kl = lambda a, c: np.sum(np.where(a > 0, a * np.log2(np.maximum(a, 1e-12) / c), 0))
            out[k, j] = 0.5 * kl(p, m) + 0.5 * kl(g, m)
    return out


def iw_weights(ds, cid, K, clip, smooth=1.0, nbins=NBINS, dp_eps=None, seed=0):
    """FedTW per-sample, per-target label-shift weights p_j(bin)/p_kj(bin).
    Clients report a histogram of their training targets over nbins global
    quantile bins (optionally with Laplace noise, epsilon-DP per histogram);
    the server sums them into the global histogram. Weights are clipped and
    renormalised to mean one inside every client."""
    n = len(cid)
    w = np.ones((n, 3), np.float32)
    rng = np.random.default_rng(999 + seed)
    ytr = ds["raw"][ds["Wtr"][:, SEQ]]
    for j in range(3):
        if nbins == NBINS:
            b = ds["bins"][:, j]
        else:
            e = np.quantile(ds["raw"][:ds["n_tr"], j], np.linspace(0, 1, nbins + 1)[1:-1])
            b = np.searchsorted(e, ytr[:, j], side="right")
        counts = np.stack([np.bincount(b[cid == k], minlength=nbins) for k in range(K)]).astype(float)
        if dp_eps:
            counts = np.maximum(counts + rng.laplace(0, 1.0 / dp_eps, counts.shape), 0)
        g = counts.sum(0) / counts.sum()
        for k in range(K):
            m = cid == k
            if not m.any():
                continue
            cnt = counts[k] + smooth
            pk = cnt / cnt.sum()
            r = np.minimum(g / pk, clip)[b[m]]
            w[m, j] = r / r.mean()
    return w


def divergence(ds, cid, K=20):
    """Sample-weighted mean Jensen-Shannon divergence (bits) between each client's
    target-bin histogram and the global histogram, per target."""
    out = []
    for j in range(3):
        b = ds["bins"][:, j]
        g = np.bincount(b, minlength=NBINS) / len(b)
        js, wsum = 0.0, 0
        for k in range(K):
            bk = b[cid == k]
            if len(bk) == 0:
                continue
            p = np.bincount(bk, minlength=NBINS) / len(bk)
            m = 0.5 * (p + g)
            kl = lambda a, c: np.sum(np.where(a > 0, a * np.log2(np.maximum(a, 1e-12) / c), 0))
            js += len(bk) * (0.5 * kl(p, m) + 0.5 * kl(g, m)); wsum += len(bk)
        out.append(js / wsum)
    return out


# ----------------------------------------------------------------------------
# batched model:  LSTM(32) encoder + one MLP head (16 ReLU -> 1) per target
# ----------------------------------------------------------------------------
H, D, F = 32, 16, 3
ENC = ("Wih", "Whh", "b")


def init_params(M, gen):
    def u(shape, fan):
        a = 1.0 / math.sqrt(fan)
        return (torch.rand(shape, generator=gen) * 2 - 1) * a
    p = {"Wih": u((M, F, 4 * H), H), "Whh": u((M, H, 4 * H), H), "b": u((M, 4 * H), H),
         "W1": u((M, 3, H, D), H), "b1": u((M, 3, D), H),
         "W2": u((M, 3, D), D), "b2": u((M, 3), D)}
    p["b"][:, H:2 * H] += 1.0
    return p


def forward(p, X, mask=None):
    """X: (M, B, SEQ, F) -> (M, B, 3)"""
    M, B = X.shape[:2]
    xg = torch.einsum("mbti,mig->mbtg", X, p["Wih"]) + p["b"][:, None, None]
    h = X.new_zeros(M, B, H); c = X.new_zeros(M, B, H)
    for t in range(X.shape[2]):
        g = xg[:, :, t] + torch.bmm(h, p["Whh"])
        i, f, gg, o = g.split(H, -1)
        c = torch.sigmoid(f) * c + torch.sigmoid(i) * torch.tanh(gg)
        h = torch.sigmoid(o) * torch.tanh(c)
    if mask is not None:
        h = h * mask
    zz = torch.relu(torch.einsum("mbh,mjhd->mbjd", h, p["W1"]) + p["b1"][:, None])
    return torch.einsum("mbjd,mjd->mbj", zz, p["W2"]) + p["b2"][:, None]


def _grad_step(p, X, y, mask, wt):
    out = forward(p, X, mask)
    loss = ((out - y).abs() * wt).mean(1).sum()
    return torch.autograd.grad(loss, list(p.values()))


_COMPILED = None


def grad_step(p, X, y, mask, wt):
    global _COMPILED
    if os.environ.get("FC_COMPILE", "1") == "1":
        if _COMPILED is None:
            _COMPILED = torch.compile(_grad_step, dynamic=False)
        return _COMPILED(p, X, y, mask, wt)
    return _grad_step(p, X, y, mask, wt)


# ----------------------------------------------------------------------------
# federated run
# ----------------------------------------------------------------------------
DEFAULT = dict(K=20, rounds=60, local_steps=25, batch=32, lr=1e-3, drop=0.2,
               eval_every=5, method="fedavg", mu=0.0, mu_max=1.0, power=1.0,
               server_lr=1.0, server_beta1=0.9, server_beta2=0.99, server_eps=1e-3,
               ema=0.5, test_curve=True)


def _bshape(v, p, S, K, head):
    """broadcast a (M,) or (M,3) coefficient to parameter p"""
    M = p.shape[0]
    if head:
        return v.view(M, 3, *[1] * (p.dim() - 2))
    return v.view(M, *[1] * (p.dim() - 1))


def run(ds, scen_name, seeds, cfg, verbose=False):
    cfg = {**DEFAULT, **cfg}
    scen = SCENARIOS[scen_name] if isinstance(scen_name, str) else scen_name
    K = cfg["K"]; S = len(seeds); M = S * K; B = cfg["batch"]
    method = cfg["method"]
    t0 = time.time()
    z = torch.from_numpy(ds["z"])
    Wtr = torch.from_numpy(ds["Wtr"])

    # ---- partitions ----------------------------------------------------------
    order, off, ln, nk, div = [], [], [], np.zeros((S, K)), []
    wlist, js_all = [], np.zeros((S, K, 3))
    pos = 0
    for si, s in enumerate(seeds):
        cid = partition(ds, scen, s, K) if K > 1 else np.zeros(len(ds["Wtr"]), np.int64)
        if K > 1:
            div.append(divergence(ds, cid, K))
            js_all[si] = client_js(ds, cid, K)
        wsamp = iw_weights(ds, cid, K, cfg.get("iw_clip", 10.0), nbins=cfg.get("iw_bins", NBINS),
                           dp_eps=cfg.get("iw_dp_eps"), seed=s) if cfg.get("iw") else None
        for k in range(K):
            idx = np.where(cid == k)[0]
            wlist.append(wsamp[idx] if wsamp is not None and len(idx) else np.ones((max(len(idx), 1), 3), np.float32))
            nk[si, k] = len(idx)
            if len(idx) == 0:
                idx = np.array([0])
            order.append(idx); off.append(pos); ln.append(len(idx)); pos += len(idx)
    order = torch.from_numpy(np.concatenate(order))
    wall = torch.from_numpy(np.concatenate(wlist))
    off = torch.tensor(off); ln = torch.tensor(ln, dtype=torch.float64)
    wts = torch.tensor(nk / nk.sum(1, keepdims=True), dtype=torch.float32)

    gen = torch.Generator().manual_seed(int(seeds[0]) * 7919 + 17 + K)
    glob = {}
    for s in seeds:
        pi = init_params(1, torch.Generator().manual_seed(int(s)))
        for n, v in pi.items():
            glob.setdefault(n, []).append(v)
    glob = {n: torch.cat(v) for n, v in glob.items()}
    names = list(glob)
    mom = {n: torch.zeros_like(v) for n, v in glob.items()}
    sv = {n: torch.zeros_like(v) for n, v in glob.items()}
    ctl_g = {n: torch.zeros_like(v) for n, v in glob.items()}                # SCAFFOLD
    ctl_k = {n: torch.zeros(S * K, *v.shape[1:]) for n, v in glob.items()}

    mu_enc = torch.full((S,), float(cfg["mu"]))
    mu_head = torch.full((S, 3), float(cfg["mu"]))
    if method == "fedprox_head":
        mu_head = torch.tensor(cfg["mu_head"], dtype=torch.float32).expand(S, 3).clone()
    if method in ("fedavg", "fedavgm", "fedadam", "scaffold", "central", "local"):
        mu_enc.zero_(); mu_head.zero_()
    js_t = torch.tensor(js_all, dtype=torch.float32)            # (S,K,3)
    if cfg.get("js_mu"):          # divergence-scaled, per-client, per-target coefficients
        mu_head_k = cfg["mu_max"] * js_t.reshape(S * K, 3)
        mu_enc_k = cfg.get("mu_enc_scale", 1.0) * mu_head_k.max(1).values

    steps = torch.full((S, K), cfg["local_steps"])
    if scen["kind"] == "sys":
        r = np.random.default_rng(777)
        choice = np.array([0.2, 0.4, 1.0])
        steps = torch.tensor(np.round(cfg["local_steps"] * choice[r.integers(0, 3, (S, K))]))
    steps = steps.reshape(M)

    Wva = torch.from_numpy(ds["Wva"]); Wte = torch.from_numpy(ds["Wte"])
    best = [dict(val=float("inf"), params=None, rnd=0) for _ in range(S)]
    hist = []
    local_state = None
    expand = lambda g: g.repeat_interleave(K, 0)

    for rnd in range(1, cfg["rounds"] + 1):
        part = torch.ones(S, K)
        if scen["kind"] == "partial":
            part.zero_()
            for si in range(S):
                part[si, torch.randperm(K, generator=gen)[: K // 2]] = 1
        part = part * (wts > 0)
        if method == "local" and local_state is not None:
            loc = {n: v.clone().requires_grad_(True) for n, v in local_state.items()}
        else:
            loc = {n: expand(v).clone().requires_grad_(True) for n, v in glob.items()}
        anc = {n: expand(v) for n, v in glob.items()}
        m1 = {n: torch.zeros_like(v) for n, v in loc.items()}
        m2 = {n: torch.zeros_like(v) for n, v in loc.items()}
        me, mh = expand(mu_enc), expand(mu_head)
        if cfg.get("js_mu"):
            me, mh = mu_enc_k, mu_head_k
        corr = {n: expand(ctl_g[n]) - ctl_k[n] for n in names} if method == "scaffold" else None
        for st in range(cfg["local_steps"]):
            act = (steps > st).float() * part.reshape(M)
            ridx = (torch.rand(M, B, generator=gen, dtype=torch.float64) * ln[:, None]).long() + off[:, None]
            rows = Wtr[order[ridx]]
            wt = wall[ridx]
            X = z[rows[..., :SEQ]]; y = z[rows[..., SEQ]]
            mask = (torch.rand(M, B, H, generator=gen) >= cfg["drop"]).float() / (1 - cfg["drop"])
            grads = grad_step(loc, X, y, mask, wt)
            with torch.no_grad():
                bc1 = 1 - 0.9 ** (st + 1); bc2 = 1 - 0.999 ** (st + 1)
                for (n, p), g in zip(loc.items(), grads):
                    head = n not in ENC
                    coef = mh if head else me
                    g = g + _bshape(coef, p, S, K, head) * (p - anc[n])
                    if corr is not None:
                        g = g + corr[n]
                    m1[n].mul_(0.9).add_(0.1 * g)
                    m2[n].mul_(0.999).add_(0.001 * g * g)
                    upd = cfg["lr"] * (m1[n] / bc1) / ((m2[n] / bc2).sqrt() + 1e-8)
                    p.sub_(upd * act.view(-1, *[1] * (p.dim() - 1)))
        # ---- aggregation ------------------------------------------------------
        with torch.no_grad():
            if method == "local":
                local_state = {n: v.detach() for n, v in loc.items()}
            w = wts * part
            w = w / w.sum(1, keepdim=True)
            num_e = torch.zeros(S); den_e = torch.zeros(S)
            num_h = torch.zeros(S, 3); den_h = torch.zeros(S, 3)
            for n in names:
                delta = (loc[n].detach() - anc[n]).view(S, K, *glob[n].shape[1:])
                wv = w.view(S, K, *[1] * (delta.dim() - 2))
                md = (wv * delta).sum(1)
                if n in ENC:
                    num_e += (w * (delta ** 2).flatten(2).sum(2)).sum(1)
                    den_e += (md ** 2).flatten(1).sum(1)
                else:
                    sq = delta ** 2 if delta.dim() == 3 else (delta ** 2).flatten(3).sum(3)
                    sm = md ** 2 if md.dim() == 2 else (md ** 2).flatten(2).sum(2)
                    num_h += (w[..., None] * sq).sum(1); den_h += sm
                if method == "fedavgm":
                    mom[n] = cfg["server_beta1"] * mom[n] + md
                    glob[n] = glob[n] + cfg["server_lr"] * mom[n]
                elif method == "fedadam":
                    mom[n] = cfg["server_beta1"] * mom[n] + (1 - cfg["server_beta1"]) * md
                    sv[n] = cfg["server_beta2"] * sv[n] + (1 - cfg["server_beta2"]) * md ** 2
                    glob[n] = glob[n] + cfg["server_lr"] * mom[n] / (sv[n].sqrt() + cfg["server_eps"])
                elif method == "scaffold":
                    # option-II control variates with the effective local step size
                    nstep = expand_steps = steps.view(S, K).clamp_min(1)
                    dk = delta
                    new_k = ctl_k[n].view(S, K, *glob[n].shape[1:]) - ctl_g[n][:, None] \
                        - dk / (nstep.view(S, K, *[1] * (dk.dim() - 2)) * cfg["lr"] * cfg.get("scaffold_scale", 1.0))
                    pk = part.view(S, K, *[1] * (dk.dim() - 2))
                    old_k = ctl_k[n].view(S, K, *glob[n].shape[1:])
                    upd_k = pk * new_k + (1 - pk) * old_k
                    ctl_g[n] = ctl_g[n] + ((upd_k - old_k).sum(1)) / K
                    ctl_k[n] = upd_k.reshape(S * K, *glob[n].shape[1:])
                    glob[n] = glob[n] + md
                else:
                    glob[n] = glob[n] + md
            rho_e = num_e / den_e.clamp_min(1e-12)
            rho_h = num_h / den_h.clamp_min(1e-12)
            if method == "adaprox":
                te = cfg["mu_max"] * (1 - 1 / rho_e.clamp_min(1.0)) ** cfg["power"]
                th = cfg["mu_max"] * (1 - 1 / rho_h.clamp_min(1.0)) ** cfg["power"]
                if cfg.get("heads_only"):
                    te = torch.zeros_like(te)
                if cfg.get("shared_mu"):          # ablation: one model-wide coefficient
                    th = te[:, None].expand(S, 3).clone()
                a = cfg["ema"] if rnd > 1 else 0.0
                mu_enc = a * mu_enc + (1 - a) * te
                mu_head = a * mu_head + (1 - a) * th
        # ---- evaluation -----------------------------------------------------------
        if rnd % cfg["eval_every"] == 0 or rnd == cfg["rounds"]:
            if method == "local":
                ev_models = [{n: v[si * K:(si + 1) * K] for n, v in local_state.items()} for si in range(S)]
                vl = [(predict(ev_models[si], z, Wva) - z[Wva[:, SEQ]]).abs().mean().item() for si in range(S)]
            else:
                ev_models = [{n: v[si:si + 1] for n, v in glob.items()} for si in range(S)]
                pv = predict_multi(glob, z, Wva)                       # (S, n, 3)
                vl = (pv - z[Wva[:, SEQ]][None]).abs().mean((1, 2)).tolist()
            rec = dict(rnd=rnd, val=vl, rho_e=rho_e.tolist(), rho_h=rho_h.tolist(),
                       mu_e=mu_enc.tolist(), mu_h=mu_head.tolist())
            if cfg["test_curve"] and method != "local" and rnd % 20 == 0:
                pt = predict_multi(glob, z, Wte)
                rec["test_r2"] = [[metrics(ds, pt[si], Wte)[t]["R2"] for t in TARGETS] for si in range(S)]
            hist.append(rec)
            for si in range(S):
                if vl[si] < best[si]["val"]:
                    best[si] = dict(val=vl[si], rnd=rnd,
                                    params={n: v.clone() for n, v in ev_models[si].items()})
            if verbose:
                print(f"  {scen_name} {method} rnd {rnd:3d} val {np.mean(vl):.4f} "
                      f"rho_e {rho_e.mean():.2f} rho_h {rho_h.mean(0).numpy().round(2)} "
                      f"mu_e {mu_enc.mean():.3f} mu_h {mu_head.mean(0).numpy().round(3)} "
                      f"{time.time()-t0:.0f}s", flush=True)

    res = []
    if method != "local":
        p_final = predict_multi(glob, z, Wte)
        bstack = {n: torch.cat([best[si]["params"][n] for si in range(S)]) for n in names}
        p_best = predict_multi(bstack, z, Wte)
    for si, s in enumerate(seeds):
        if method == "local":
            final = {n: v[si * K:(si + 1) * K] for n, v in local_state.items()}
        else:
            final = {n: v[si:si + 1] for n, v in glob.items()}
        for tag, prm in (("best", best[si]["params"]), ("final", final)):
            if method != "local":
                pr = p_best[si] if tag == "best" else p_final[si]
            else:
                pr = predict(prm, z, Wte)
            rec = dict(seed=int(s), ckpt=tag, best_round=best[si]["rnd"],
                       metrics=metrics(ds, pr, Wte))
            if tag == "best":
                rec.update(robust(ds, pr, Wte))
            res.append(rec)
    return dict(results=res, hist=hist, seconds=time.time() - t0,
                divergence=div, n_k=nk.tolist(), js=js_all.mean(1).tolist())


_FWD = None


@torch.no_grad()
def predict_multi(prm, z, W, bs=4096):
    """S stacked global models evaluated on the same windows -> (S, n, 3).
    Fixed-size (padded) chunks so the compiled forward is traced once."""
    global _FWD
    if _FWD is None:
        _FWD = torch.compile(forward, dynamic=False) if os.environ.get("FC_COMPILE", "1") == "1" else forward
    Mm = prm["Wih"].shape[0]
    n = W.shape[0]
    outs = []
    for i in range(0, n, bs):
        w = W[i:i + bs]
        m = len(w)
        if m < bs:
            w = torch.cat([w, w[-1:].expand(bs - m, -1)])
        X = z[w[:, :SEQ]]
        outs.append(_FWD(prm, X[None].expand(Mm, *X.shape))[:, :m])
    return torch.cat(outs, 1)


@torch.no_grad()
def predict(prm, z, W, bs=16384):
    """global model -> (n,3); local models (K>1 slices) -> mean ensemble (n,3)"""
    outs = []
    Mm = prm["Wih"].shape[0]
    for i in range(0, W.shape[0], bs):
        X = z[W[i:i + bs, :SEQ]]
        o = forward(prm, X[None].expand(Mm, *X.shape))
        outs.append(o.mean(0))
    return torch.cat(outs)


def _r2(a, p):
    return 100 * (1 - ((a - p) ** 2).sum(0) / ((a - a.mean(0)) ** 2).sum(0))


def robust(ds, pr, W, nboot=200, block=1000):
    """R2 on four consecutive test blocks (temporal holdouts) and on moving-block
    bootstrap resamples of the test period (identical resamples for every run)."""
    pr = pr.numpy().astype(np.float64)
    yt = ds["z"][W[:, SEQ].numpy()].astype(np.float64)
    rp = np.expm1(pr * ds["iqr"] + ds["med"]); rt = np.expm1(yt * ds["iqr"] + ds["med"])
    n = len(rt)
    q = [_r2(rt[a:b], rp[a:b]).round(3).tolist()
         for a, b in zip(np.linspace(0, n, 5).astype(int)[:-1], np.linspace(0, n, 5).astype(int)[1:])]
    rng = np.random.default_rng(12345)
    nb = int(np.ceil(n / block))
    starts = rng.integers(0, n - block, (nboot, nb))
    boot = []
    for r in range(nboot):
        idx = (starts[r][:, None] + np.arange(block)[None]).ravel()[:n]
        boot.append(_r2(rt[idx], rp[idx]).round(3).tolist())
    return dict(quarters=q, boot=boot)


def metrics(ds, pr, W):
    pr = pr.numpy().astype(np.float64)
    yt = ds["z"][W[:, SEQ].numpy()].astype(np.float64)
    lp = pr * ds["iqr"] + ds["med"]; lt = yt * ds["iqr"] + ds["med"]
    rp, rt = np.expm1(lp), np.expm1(lt)
    out = {}
    for j, t in enumerate(TARGETS):
        a, p = rt[:, j], rp[:, j]
        out[t] = dict(
            R2=float(100 * (1 - ((a - p) ** 2).sum() / ((a - a.mean()) ** 2).sum())),
            R2_log=float(100 * (1 - ((lt[:, j] - lp[:, j]) ** 2).sum() / ((lt[:, j] - lt[:, j].mean()) ** 2).sum())),
            MAE=float(np.abs(a - p).mean()),
            SMAPE=float(100 * np.mean(2 * np.abs(p - a) / (np.abs(a) + np.abs(p) + 1e-12))))
    return out
