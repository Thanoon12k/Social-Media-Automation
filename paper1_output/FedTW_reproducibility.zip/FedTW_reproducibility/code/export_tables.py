"""Writes the manuscript tables (outputs/tables.json) as CSV files, one per table."""
import csv, json, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "outputs")
T = json.load(open(os.path.join(OUT, "tables.json")))
for key, t in T.items():
    path = os.path.join(OUT, f"Table{t['num']}_{key}.csv")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(t["header"])
        for r in t["rows"]:
            w.writerow([str(c).strip("*") for c in r])
    print("wrote", os.path.basename(path))
