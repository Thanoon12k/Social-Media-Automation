#!/bin/bash
# Statistics, tables and figures from ../results (takes about 1 minute; no training).
set -e
cd "$(dirname "$0")"
python3 analyze.py > ../outputs/analysis_summary.txt
python3 make_numbers.py
python3 figures.py
python3 fig1_schematic.py
python3 export_tables.py
echo "outputs written to ../outputs"
