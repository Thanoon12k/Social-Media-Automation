"""Runs the full experiment grid for one trace; one JSON per configuration.

usage:  python run_grid.py alibaba|in2p3 [group ...]
"""
import json, os, sys, time
import numpy as np
import fedcloud as fc

SEEDS = list(range(10))
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")

MAIN_SCEN = ["IID", "QTY", "TEMP", "LS-dur-1.0", "LS-dur-0.3", "LS-dur-0.1",
             "LS-cpu-0.1", "LS-mem-0.1", "BAND-dur", "SYS", "PART"]
MU_GRID = [0.001, 0.01, 0.1, 0.3, 1.0, 3.0, 10.0]


def methods():
    """name -> cfg, filled in from methods.json so the grid and the paper agree"""
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "methods.json")) as f:
        return json.load(f)


SWEEP_SCEN = ["IID", "LS-dur-0.1", "LS-cpu-0.1", "BAND-dur"]
CORE_SCEN = ["IID", "LS-dur-0.1", "LS-cpu-0.1", "BAND-dur", "LS-dur-0.3", "LS-dur-1.0",
             "LS-mem-0.1", "QTY", "TEMP"]
REST_SCEN = ["SYS", "PART"]


def tuned_mu(name):
    """FedProx coefficient tuned once per trace: lowest mean best-validation MAE
    over the sweep scenarios (validation data only)."""
    best = None
    for mu in MU_GRID:
        v = []
        for s in SWEEP_SCEN:
            p = os.path.join(OUT, name, f"{s}__fedprox_mu{mu}.json")
            r = json.load(open(p))
            v.append(np.mean([min(h["val"][i] for h in r["hist"]) for i in range(len(r["hist"][0]["val"]))]))
        if best is None or np.mean(v) < best[0]:
            best = (np.mean(v), mu)
    return best[1]


def groups(name):
    M = methods()
    g = {}
    g["central"] = [("CENTRAL", "central", dict(K=1, method="central"))]
    # centralised reference with the same number of samples as the whole federation
    g["central_long"] = [("CENTRAL", "central_long", dict(K=1, method="central", local_steps=500))]
    core = ["fedavg", "fedtw", "fedadam", "fedtw_adam"]
    g["core"] = [(s, n, M[n]) for s in CORE_SCEN for n in core]
    g["sweep"] = [(s, f"fedprox_mu{mu}", dict(method="fedprox", mu=mu), 5)
                  for s in SWEEP_SCEN for mu in MU_GRID]
    g["prox"] = [(s, "fedprox", "PROX") for s in CORE_SCEN + REST_SCEN]
    g["rest"] = [(s, n, M[n]) for s in REST_SCEN for n in core] + \
                [(s, "fedavgm", M["fedavgm"]) for s in ["IID", "LS-dur-0.1", "LS-cpu-0.1", "BAND-dur"]]
    g["abl"] = [(s, n, c, 5) for s in ["LS-dur-0.1", "BAND-dur", "LS-cpu-0.1"] for n, c in [
        ("fedtw_bins5", dict(method="fedavg", iw=True, iw_bins=5)),
        ("fedtw_bins20", dict(method="fedavg", iw=True, iw_bins=20)),
        ("fedtw_clip3", dict(method="fedavg", iw=True, iw_clip=3.0)),
        ("fedtw_dp1", dict(method="fedavg", iw=True, iw_dp_eps=1.0)),
        ("fedtw_dp0.1", dict(method="fedavg", iw=True, iw_dp_eps=0.1)),
        ("fedprox_durhead", dict(method="fedprox_head", mu=0.0, mu_head=[1.0, 0.0, 0.0])),
        ("fedavg_tau5_R300", dict(method="fedavg", local_steps=5, rounds=300, eval_every=25)),
        ("fedtw_prox", dict(method="fedprox", mu=1.0, iw=True))]]
    # longer budget (3x rounds) to check that gains are not only faster convergence
    g["long"] = [(s, f"{n}_R180", dict(c, rounds=180, eval_every=10), 5)
                 for s in ["IID", "LS-dur-0.1", "BAND-dur"]
                 for n, c in [("fedavg", M["fedavg"]), ("fedprox1", dict(method="fedprox", mu=1.0)),
                              ("fedtw", M["fedtw"])]]
    return g


def main():
    name = sys.argv[1]
    which = sys.argv[2:] or ["central", "core", "sweep", "prox", "abl", "rest"]
    ds = fc.load(name)
    os.makedirs(os.path.join(OUT, name), exist_ok=True)
    G = groups(name)
    for grp in which:
        for item in G[grp]:
            scen, mname, cfg = item[:3]
            seeds = SEEDS[:item[3]] if len(item) > 3 else SEEDS
            if cfg == "PROX":
                cfg = dict(method="fedprox", mu=tuned_mu(name))
            path = os.path.join(OUT, name, f"{scen}__{mname}.json")
            if os.path.exists(path):
                continue
            t = time.time()
            r = fc.run(ds, "IID" if scen == "CENTRAL" else scen, seeds, cfg)
            r.update(dataset=name, scenario=scen, method=mname, cfg=cfg)
            with open(path, "w") as f:
                json.dump(r, f)
            b = [x for x in r["results"] if x["ckpt"] == "best"]
            print(f"[{name}] {scen:11s} {mname:18s} " + " ".join(
                f"{t_[:4]}={np.mean([x['metrics'][t_]['R2'] for x in b]):6.2f}" for t_ in fc.TARGETS)
                + f"  {time.time()-t:.0f}s", flush=True)


if __name__ == "__main__":
    main()
