"""Computes every number and table quoted in the manuscript -> outputs/numbers.json,
outputs/tables.json and outputs/analysis/contrasts.csv."""
import json, os
import numpy as np
import pandas as pd
from scipy import stats
import fedcloud as fc
from analyze import load_all, contrast, TARGETS, TNAME, OUT, ci_t

HERE = os.path.dirname(os.path.abspath(__file__))
MAN = os.path.join(HERE, "..", "outputs")
DS = ["alibaba", "in2p3"]
DSN = {"alibaba": "Alibaba", "in2p3": "CC-IN2P3"}
SH = {"alibaba": "ali", "in2p3": "in2"}
TS = {"duration": "dur", "real_cpu_avg": "cpu", "real_mem_avg": "mem"}
SCEN_ORDER = ["IID", "QTY", "TEMP", "SYS", "PART", "LS-dur-1.0", "LS-dur-0.3", "LS-dur-0.1",
              "BAND-dur", "LS-cpu-0.1", "LS-mem-0.1"]
SKEWED = {"LS-dur-1.0": "duration", "LS-dur-0.3": "duration", "LS-dur-0.1": "duration",
          "BAND-dur": "duration", "LS-cpu-0.1": "real_cpu_avg", "LS-mem-0.1": "real_mem_avg"}
SCEN_DESC = {
    "IID": ("Uniform random assignment of windows", "Reference, no heterogeneity"),
    "QTY": ("Random content, client sizes ~ Dirichlet(0.5)", "Quantity skew"),
    "TEMP": ("20 consecutive time blocks of the training period", "Temporal silos"),
    "SYS": ("IID data; 20%, 40% or 100% of local steps", "System heterogeneity"),
    "PART": ("IID data; 10 of 20 clients per round", "Partial participation"),
    "LS-dur-1.0": ("Duration bins spread by Dirichlet(1.0)", "Mild duration skew"),
    "LS-dur-0.3": ("Duration bins spread by Dirichlet(0.3)", "Moderate duration skew"),
    "LS-dur-0.1": ("Duration bins spread by Dirichlet(0.1)", "Severe duration skew"),
    "BAND-dur": ("80% sorted into 20 duration bands, 20% uniform", "Extreme duration skew (earlier S4)"),
    "LS-cpu-0.1": ("CPU bins spread by Dirichlet(0.1)", "Severe CPU skew"),
    "LS-mem-0.1": ("Memory bins spread by Dirichlet(0.1)", "Severe memory skew"),
}

df, boots, quarters, hists, meta = load_all()
B = df[df.ckpt == "best"]


def m(d, s, meth, t, stat="mean", seeds=None):
    v = B[(B.dataset == d) & (B.scenario == s) & (B.method == meth) & (B.target == t)]
    if seeds is not None:
        v = v[v.seed < seeds]
    v = v.R2
    if len(v) == 0:
        return np.nan
    return {"mean": v.mean(), "sd": v.std(ddof=1), "n": len(v)}[stat]


def fmt(x, nd=2):
    return "–" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x:.{nd}f}"


def pfmt(p):
    return "<0.001" if p < 0.001 else f"{p:.3f}"


N = {}
T = {}
# ------------------------------------------------------------------ data facts
for d in DS:
    ds = fc.load(d)
    N[f"N_{SH[d]}"] = ds["N"]
    N[f"ntr_{SH[d]}"] = len(ds["Wtr"]); N[f"nva_{SH[d]}"] = len(ds["Wva"]); N[f"nte_{SH[d]}"] = len(ds["Wte"])
N["n_scen"] = len(SCEN_ORDER)

# ------------------------------------------------------------------ tuned mu
import run_grid
for d in DS:
    try:
        N[f"mu_{SH[d]}"] = run_grid.tuned_mu(d)
    except Exception:
        N[f"mu_{SH[d]}"] = float("nan")

# ------------------------------------------------------------------ references
for d in DS:
    for t in TARGETS:
        k = f"{SH[d]}_{TS[t]}"
        N[f"cen_{k}"] = m(d, "CENTRAL", "central", t)
        N[f"cenL_{k}"] = m(d, "CENTRAL", "central_long", t)
        for meth in ["fedavg", "fedprox", "fedavgm", "fedadam", "fedtw", "fedtw_adam"]:
            for s in SCEN_ORDER:
                N[f"{meth}_{s.replace('-', '').replace('.', '')}_{k}"] = m(d, s, meth, t)

# ------------------------------------------------------------------ Table: regimes + divergence
rows = []
for s in SCEN_ORDER:
    desc, ch = SCEN_DESC[s]
    div = []
    for d in DS:
        md = meta.get((d, s, "fedavg"))
        v = np.mean(md["divergence"], 0) if md and md["divergence"] else [np.nan] * 3
        div += [fmt(x, 3) for x in v]
    rows.append([s, desc, ch] + div)
T["scen"] = dict(num=1, caption="Client regimes and measured heterogeneity. JS is the sample-weighted Jensen–Shannon divergence (bits) between each client's target histogram (ten training-quantile bins) and the global histogram, averaged over ten partition seeds.",
                 header=["Regime", "Construction of the 20 clients", "Heterogeneity modelled",
                         "JS dur. (Ali)", "JS CPU (Ali)", "JS mem. (Ali)", "JS dur. (IN2P3)", "JS CPU (IN2P3)", "JS mem. (IN2P3)"],
                 rows=rows)
N["T_scen"] = 1

# ------------------------------------------------------------------ Table: FedAvg by regime (diagnosis)
rows = []
for d in DS:
    for s in ["CENTRAL", "CENTRAL_L"] + SCEN_ORDER:
        meth = {"CENTRAL": "central", "CENTRAL_L": "central_long"}.get(s, "fedavg")
        lab = {"CENTRAL": "Centralised (equal steps)", "CENTRAL_L": "Centralised (equal samples)"}.get(s, s)
        s = "CENTRAL" if s == "CENTRAL_L" else s
        r = [DSN[d], lab]
        for t in TARGETS:
            mu, sd = m(d, s, meth, t), m(d, s, meth, t, "sd")
            base = m(d, "IID", "fedavg", t)
            cell = f"{fmt(mu)} ± {fmt(sd)}"
            if s not in ("CENTRAL", "IID") and not np.isnan(mu):
                dd = round(mu - base, 1)
                cell += " (0.0)" if dd == 0 else f" ({dd:+.1f})".replace("-", "−")
            if s in SKEWED and SKEWED[s] == t:
                cell = "**" + cell
            r.append(cell)
        rows.append(r)
T["fedavg"] = dict(num=2, caption="Test R² (%) of FedAvg in every regime (mean ± s.d. over ten seeds; change relative to IID FedAvg in parentheses). The skewed target of each target-skew regime is in bold.",
                   header=["Trace", "Regime", "Duration", "CPU", "Memory"], rows=rows)
N["T_fedavg"] = 2

# divergence-damage association (FedAvg, all regimes, all targets, both traces)
xs, ys = [], []
for d in DS:
    for s in SCEN_ORDER:
        md = meta.get((d, s, "fedavg"))
        if not md or not md["divergence"]:
            continue
        dv = np.mean(md["divergence"], 0)
        for j, t in enumerate(TARGETS):
            xs.append(dv[j]); ys.append(m(d, s, "fedavg", t) - m(d, "IID", "fedavg", t))
ok = ~np.isnan(ys)
if ok.sum() > 3:
    rho, p = stats.spearmanr(np.array(xs)[ok], np.array(ys)[ok])
    N["spear_rho"], N["spear_n"] = rho, int(ok.sum())
    N["spear_rho_s"] = f"{rho:.2f}".replace("-", "−")
    N["spear_p"] = "< 0.001" if p < 0.001 else f"= {p:.3f}"

# ------------------------------------------------------------------ mu sweep table
MU = [0.001, 0.01, 0.1, 0.3, 1.0, 3.0, 10.0]
rows = []
for d in DS:
    for s in ["IID", "LS-dur-0.1", "LS-cpu-0.1", "BAND-dur"]:
        for t in TARGETS:
            fa = m(d, s, "fedavg", t, seeds=5)
            vals = [m(d, s, f"fedprox_mu{mu}", t) for mu in MU]
            best = int(np.nanargmax(vals)) if not np.all(np.isnan(vals)) else 0
            cells = [fmt(v) for v in vals]
            if not np.isnan(vals[best]):
                cells[best] = "**" + cells[best]
            rows.append([DSN[d], s, TNAME[t], fmt(fa)] + cells + [fmt(m(d, s, "fedtw", t, seeds=None))])
            N[f"sweep_best_{SH[d]}_{s.replace('-', '').replace('.', '')}_{TS[t]}"] = MU[best]
            N[f"sweep_bestval_{SH[d]}_{s.replace('-', '').replace('.', '')}_{TS[t]}"] = vals[best]
T["sweep"] = dict(num=3, caption="FedProx coefficient sweep at a matched budget (test R², %, mean over five seeds). FedAvg uses the same five seeds; FedTW is shown for reference (ten seeds). The best coefficient of each row is in bold.",
                  header=["Trace", "Regime", "Target", "FedAvg"] + [f"μ={mu:g}" for mu in MU] + ["FedTW"], rows=rows)
N["T_sweep"] = 3

# ------------------------------------------------------------------ main comparison table
METHS = ["fedavg", "fedprox", "fedavgm", "fedadam", "fedtw", "fedtw_adam"]
MN = {"fedavg": "FedAvg", "fedprox": "FedProx", "fedavgm": "FedAvgM", "fedadam": "FedAdam",
      "fedtw": "FedTW", "fedtw_adam": "FedTW+FedAdam"}
rows = []
for d in DS:
    for s in SCEN_ORDER:
        for t in TARGETS:
            if s in SKEWED and SKEWED[s] != t:
                continue
            if s not in SKEWED and t != "duration" and s != "IID":
                continue
            vals = [m(d, s, x, t) for x in METHS]
            cells = [fmt(v) for v in vals]
            if not np.all(np.isnan(vals)):
                b = int(np.nanargmax(vals)); cells[b] = "**" + cells[b]
            rows.append([DSN[d], s, TNAME[t], fmt(m(d, "CENTRAL", "central", t))] + cells)
T["main"] = dict(note="FedAvgM was evaluated on IID, LS-dur-0.1, LS-cpu-0.1 and BAND-dur only (– elsewhere). Central: centralised model with the same number of optimiser steps.", num=4, caption="Comparison of methods at a matched budget (test R², %, mean over ten seeds). Rows show the skewed target of each target-skew regime, all three targets under IID, and duration for the remaining regimes; the complete table with all targets and intervals is in Additional file 1. The best federated method of each row is in bold.",
                 header=["Trace", "Regime", "Target", "Central"] + [MN[x] for x in METHS], rows=rows)
N["T_main"] = 4

# ------------------------------------------------------------------ contrasts
C = []
skew_scen = list(SKEWED)
# H1: FedTW vs FedAvg on the skewed target of every target-skew regime
c1 = contrast(df, boots, "fedtw", "fedavg", skew_scen, "H1_skewed_target")
c1 = c1[c1.apply(lambda r: SKEWED[r.scenario] == r.target, axis=1)].copy()
from analyze import holm
c1["p_holm"] = holm(c1.p_wilcoxon.values); C.append(c1)
# H2: FedTW vs FedAvg on the non-skewed targets and non-skew regimes (no-harm)
c2 = contrast(df, boots, "fedtw", "fedavg", SCEN_ORDER, "H2_other_cells")
c2 = c2[~c2.apply(lambda r: r.scenario in SKEWED and SKEWED[r.scenario] == r.target, axis=1)].copy()
c2["p_holm"] = holm(c2.p_wilcoxon.values); C.append(c2)
# H3: FedTW+FedAdam vs FedAdam on skewed targets
c3 = contrast(df, boots, "fedtw_adam", "fedadam", skew_scen, "H3_twadam_vs_adam")
c3 = c3[c3.apply(lambda r: SKEWED[r.scenario] == r.target, axis=1)].copy()
c3["p_holm"] = holm(c3.p_wilcoxon.values); C.append(c3)
# H4: FedTW vs tuned FedProx on skewed targets
c4 = contrast(df, boots, "fedtw", "fedprox", skew_scen, "H4_tw_vs_prox")
c4 = c4[c4.apply(lambda r: SKEWED[r.scenario] == r.target, axis=1)].copy()
c4["p_holm"] = holm(c4.p_wilcoxon.values); C.append(c4)
# H5: tuned FedProx vs FedAvg, all cells
c5 = contrast(df, boots, "fedprox", "fedavg", SCEN_ORDER, "H5_prox_vs_avg"); C.append(c5)
CC = pd.concat(C)
CC.to_csv(os.path.join(OUT, "contrasts.csv"), index=False)

rows = []
for _, r in c1.iterrows():
    rows.append([DSN[r.dataset], r.scenario, TNAME[r.target], fmt(r.mean_b), fmt(r.mean_a),
                 f"{r.delta:+.2f} [{r.ci_lo:+.2f}, {r.ci_hi:+.2f}]", f"[{r.boot_lo:+.2f}, {r.boot_hi:+.2f}]",
                 f"{r.wins}/10", pfmt(r.p_holm)])
T["h1"] = dict(num=5, caption="FedTW versus FedAvg on the skewed target (paired by seed, n = 10). Δ is the mean paired difference in R² points with a 95% t-interval; the bootstrap interval reflects test-data uncertainty (moving-block bootstrap of the test period); p is the two-sided Wilcoxon signed-rank p-value after Holm correction over the twelve rows of this table.",
               header=["Trace", "Regime", "Target", "FedAvg", "FedTW", "Δ [95% CI]", "Bootstrap 95% CI", "Seeds improved", "p (Holm)"],
               rows=rows)
N["T_h1"] = 5

# summary numbers for the text
for _, r in c1.iterrows():
    k = f"{SH[r.dataset]}_{r.scenario.replace('-', '').replace('.', '')}"
    N[f"d1_{k}"] = r.delta; N[f"d1lo_{k}"] = r.ci_lo; N[f"d1hi_{k}"] = r.ci_hi; N[f"p1_{k}"] = pfmt(r.p_holm)
    ref = m(r.dataset, "IID", "fedavg", r.target)       # same-budget IID reference
    gap = ref - r.mean_b
    N[f"rec_{k}"] = 100 * r.delta / gap if gap > 0 else np.nan
N["rec_ali_band"] = N.get("rec_ali_BANDdur", np.nan)
N["rec_in2_band"] = N.get("rec_in2_BANDdur", np.nan)
N["h1_all_sig"] = bool((c1.p_holm < 0.05).all()) if len(c1) else False
N["h1_n"] = len(c1)
N["h2_n"] = len(c2); N["h2_maxabs"] = float(c2.delta.abs().max()) if len(c2) else np.nan
N["h2_nsig_neg"] = int(((c2.p_holm < 0.05) & (c2.delta < 0)).sum()) if len(c2) else 0
N["h2_nsig_pos"] = int(((c2.p_holm < 0.05) & (c2.delta > 0)).sum()) if len(c2) else 0
N["h2_min"] = float(c2.delta.min()) if len(c2) else np.nan
N["h3_n"] = len(c3); N["h3_nsig"] = int((c3.p_holm < 0.05).sum()) if len(c3) else 0
N["h4_n"] = len(c4); N["h4_nsig"] = int(((c4.p_holm < 0.05) & (c4.delta > 0)).sum()) if len(c4) else 0
N["h5_n"] = len(c5)
if len(c5):
    c5["p_holm"] = holm(c5.p_wilcoxon.values)
    N["h5_nsig_pos"] = int(((c5.p_holm < 0.05) & (c5.delta > 0)).sum())
    N["h5_nsig_neg"] = int(((c5.p_holm < 0.05) & (c5.delta < 0)).sum())
    N["h5_nneg"] = int((c5.delta < 0).sum())

# temporal hold-out consistency of H1
cons = []
for _, r in c1.iterrows():
    j = TARGETS.index(r.target)
    qa = np.mean([quarters[(r.dataset, r.scenario, "fedtw", s)][:, j] for s in range(10)], 0)
    qb = np.mean([quarters[(r.dataset, r.scenario, "fedavg", s)][:, j] for s in range(10)], 0)
    cons.append((qa - qb > 0).sum())
N["h1_quarters_all"] = int(sum(c == 4 for c in cons)); N["h1_quarters_total"] = len(cons)
N["h1_quarter_min"] = int(min(cons)) if cons else 0

# ------------------------------------------------------------------ ablations
ABL = [("fedavg", "FedAvg"), ("fedtw", "FedTW (Q = 10, c = 10)"), ("fedtw_bins5", "FedTW, Q = 5"),
       ("fedtw_bins20", "FedTW, Q = 20"), ("fedtw_clip3", "FedTW, c = 3"), ("fedtw_dp1", "FedTW, DP histograms ε = 1"),
       ("fedtw_dp0.1", "FedTW, DP histograms ε = 0.1"), ("fedtw_prox", "FedTW + proximal term (μ = 1)"),
       ("fedprox_durhead", "Proximal term on duration head only (μ = 1)"),
       ("fedavg_tau5_R300", "FedAvg, τ = 5 and 300 rounds (5× communication)")]
rows = []
for name, lab in ABL:
    r = [lab]
    for d in DS:
        for s in ["LS-dur-0.1", "BAND-dur", "LS-cpu-0.1"]:
            t = SKEWED[s]
            r.append(fmt(m(d, s, name, t, seeds=5)))
    rows.append(r)
T["abl"] = dict(num=6, caption="Ablations and alternative remedies (test R² of the skewed target, %, mean over seeds 0–4).",
                header=["Variant", "Ali LS-dur-0.1", "Ali BAND-dur", "Ali LS-cpu-0.1", "IN2P3 LS-dur-0.1", "IN2P3 BAND-dur", "IN2P3 LS-cpu-0.1"],
                rows=rows)
N["T_abl"] = 6
for name, _ in ABL:
    for d in DS:
        for s in ["LS-dur-0.1", "BAND-dur", "LS-cpu-0.1"]:
            N[f"abl_{name.replace('.', '')}_{SH[d]}_{s.replace('-', '').replace('.', '')}"] = m(d, s, name, SKEWED[s], seeds=5)

# ------------------------------------------------------------------ long budget
for d in DS:
    for s in ["IID", "LS-dur-0.1", "BAND-dur"]:
        for nme in ["fedavg_R180", "fedprox1_R180", "fedtw_R180"]:
            N[f"long_{nme}_{SH[d]}_{s.replace('-', '').replace('.', '')}"] = m(d, s, nme, "duration")

# ------------------------------------------------------------------ cost
sec = {k: v["seconds"] for k, v in meta.items()}
for meth in ["fedavg", "fedtw"]:
    v = [sec[k] for k in sec if k[2] == meth]
    N[f"sec_{meth}"] = float(np.mean(v)) if v else np.nan
N["tw_overhead_pct"] = 100 * (N["sec_fedtw"] / N["sec_fedavg"] - 1)

# ------------------------------------------------------------------ derived text numbers
def lossv(d, s, t):
    return m(d, "IID", "fedavg", t) - m(d, s, "fedavg", t)
for d in DS:
    N[f"loss_{SH[d]}_ls01"] = lossv(d, "LS-dur-0.1", "duration")
    N[f"loss_{SH[d]}_band"] = lossv(d, "BAND-dur", "duration")
    N[f"loss_{SH[d]}_cpu"] = lossv(d, "LS-cpu-0.1", "real_cpu_avg")
    for s in ["LS-dur-0.1", "BAND-dur"]:
        N[f"fedavg5_{SH[d]}_{s.replace('-', '').replace('.', '')}"] = m(d, s, "fedavg", "duration", seeds=5)
for d in DS:
    N[f"loss_{SH[d]}_sys"] = lossv(d, "SYS", "duration")
    N[f"loss_{SH[d]}_mem"] = lossv(d, "LS-mem-0.1", "real_mem_avg")
    N[f"spill_{SH[d]}_cpu"] = lossv(d, "LS-cpu-0.1", "duration")
    N[f"spill_{SH[d]}_mem"] = lossv(d, "LS-mem-0.1", "duration")
N["spill_ali_max"] = max(N["spill_ali_cpu"], N["spill_ali_mem"])
N["benign_max"] = max(abs(lossv(d, s, t)) for d in DS for s in ["QTY", "TEMP", "PART"] for t in TARGETS)
N["offtarget_max"] = max(abs(lossv(d, s, t)) for d in DS for s in ["LS-dur-0.1", "BAND-dur"]
                         for t in ["real_cpu_avg", "real_mem_avg"])
N["cenL_maxdiff"] = max(abs(m(d, "CENTRAL", "central_long", t) - m(d, "CENTRAL", "central", t))
                        for d in DS for t in TARGETS)
N["h1_pmax"] = pfmt(c1.p_holm.max()) if len(c1) else "–"
N["h1_allseeds"] = int((c1.wins == c1.n).sum()) if len(c1) else 0
N["h1_boot_pos"] = int((c1.boot_lo > 0).sum()) if len(c1) else 0
bd = []
for d in DS:
    for s in ["LS-dur-0.1", "BAND-dur", "LS-cpu-0.1"]:
        t = SKEWED[s]; base = m(d, s, "fedtw", t, seeds=5)
        bd += [abs(m(d, s, "fedtw_bins5", t, seeds=5) - base), abs(m(d, s, "fedtw_bins20", t, seeds=5) - base)]
N["abl_bins_maxdiff"] = float(np.nanmax(bd))
ret = []
for d in DS:
    for s in ["LS-dur-0.1", "BAND-dur", "LS-cpu-0.1"]:
        t = SKEWED[s]; fa = m(d, s, "fedavg", t, seeds=5); tw = m(d, s, "fedtw", t, seeds=5)
        ret.append((m(d, s, "fedtw_dp0.1", t, seeds=5) - fa) / (tw - fa))
N["abl_dp01_retain"] = 100 * float(np.nanmean(ret))

N["h2_min_abs"] = abs(min(0.0, N["h2_min"])) if N.get("h2_min") is not None else np.nan
N["h2_max"] = float(c2.delta.max()) if len(c2) else np.nan
gains = []
for d in DS:
    for s in ["LS-dur-0.1", "LS-cpu-0.1", "BAND-dur"]:
        t = SKEWED[s]
        v = [m(d, s, f"fedprox_mu{mu}", t) for mu in MU]
        gains.append(np.nanmax(v) - m(d, s, "fedavg", t, seeds=5))
N["sweep_maxgain"] = float(np.nanmax(gains))

json.dump({k: (None if isinstance(v, float) and np.isnan(v) else v) for k, v in N.items()},
          open(os.path.join(MAN, "numbers.json"), "w"), indent=0, default=float)
json.dump(T, open(os.path.join(MAN, "tables.json"), "w"), indent=0)
print(len(N), "numbers;", len(T), "tables")
