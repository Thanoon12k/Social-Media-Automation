"""Figures for the manuscript (reads results/*/*.json via analyze.load_all)."""
import os, json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from analyze import load_all, TARGETS, TNAME

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, "..", "outputs", "figures")
os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.dpi": 300, "savefig.bbox": "tight"})
DS = [("alibaba", "Alibaba 2017"), ("in2p3", "CC-IN2P3 2024")]
COL = {"fedavg": "#6b6b6b", "fedprox": "#d08c2b", "fedavgm": "#8c6bb1", "fedadam": "#2b83ba",
       "fedtw": "#1a9850", "fedtw_adam": "#0b5d2e", "central": "#000000"}
LAB = {"fedavg": "FedAvg", "fedprox": "FedProx (tuned μ)", "fedavgm": "FedAvgM", "fedadam": "FedAdam",
       "fedtw": "FedTW", "fedtw_adam": "FedTW + FedAdam", "central": "Centralised"}


def mean_r2(df, d, s, m, t, ckpt="best"):
    v = df[(df.dataset == d) & (df.scenario == s) & (df.method == m) & (df.target == t) & (df.ckpt == ckpt)].R2
    return v.mean(), v.std(ddof=1), len(v)


def fig_divergence(df, meta):
    """accuracy loss of FedAvg relative to IID vs measured JS divergence, per target"""
    scen = ["QTY", "TEMP", "LS-dur-1.0", "LS-dur-0.3", "LS-dur-0.1", "LS-cpu-0.1", "LS-mem-0.1", "BAND-dur"]
    mk = {"duration": "o", "real_cpu_avg": "s", "real_mem_avg": "^"}
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.0))
    for ax, (d, dn) in zip(axs, DS):
        for j, t in enumerate(TARGETS):
            base = mean_r2(df, d, "IID", "fedavg", t)[0]
            xs, ys = [], []
            for s in scen:
                k = (d, s, "fedavg")
                if k not in meta or meta[k]["divergence"] is None:
                    continue
                xs.append(np.mean([v[j] for v in meta[k]["divergence"]]))
                ys.append(mean_r2(df, d, s, "fedavg", t)[0] - base)
            ax.scatter(xs, ys, marker=mk[t], s=28, label=TNAME[t], alpha=0.85)
        ax.axhline(0, color="k", lw=0.6)
        ax.set_title(dn); ax.set_xlabel("JS divergence of the target (bits)")
    axs[0].set_ylabel("ΔR² of FedAvg vs IID (points)")
    axs[0].legend(frameon=False)
    fig.savefig(os.path.join(FIG, "fig2_divergence.png")); plt.close(fig)


def fig_sweep(df):
    mus = [0.001, 0.01, 0.1, 0.3, 1.0, 3.0, 10.0]
    scen = ["IID", "LS-dur-0.1", "LS-cpu-0.1", "BAND-dur"]
    fig, axs = plt.subplots(2, 4, figsize=(9.0, 4.6), sharex=True)
    for r, (d, dn) in enumerate(DS):
        for c, s in enumerate(scen):
            ax = axs[r, c]
            for j, t in enumerate(TARGETS):
                ys = [mean_r2(df, d, s, f"fedprox_mu{mu}", t)[0] for mu in mus]
                l, = ax.plot(mus, ys, marker="o", ms=3, label=TNAME[t])
                fa = df[(df.dataset == d) & (df.scenario == s) & (df.method == "fedavg") & (df.target == t) & (df.ckpt == "best") & (df.seed < 5)].R2.mean()
                ax.axhline(fa, color=l.get_color(), ls=":", lw=0.9)
            ax.set_xscale("log")
            if r == 0: ax.set_title(s)
            if c == 0: ax.set_ylabel(f"{dn}\nTest R² (%)")
            if r == 1: ax.set_xlabel("μ")
    axs[0, 0].legend(frameon=False, fontsize=7)
    fig.savefig(os.path.join(FIG, "fig3_mu_sweep.png")); plt.close(fig)


def fig_methods(df, methods, scen):
    fig, axs = plt.subplots(2, 3, figsize=(9.0, 5.6), sharex=True)
    w = 0.8 / len(methods)
    for r, (d, dn) in enumerate(DS):
        for c, t in enumerate(TARGETS):
            ax = axs[r, c]
            for i, m in enumerate(methods):
                mu = [mean_r2(df, d, s, m, t) for s in scen]
                ax.bar(np.arange(len(scen)) + i * w - 0.4 + w / 2, [x[0] for x in mu], w,
                       yerr=[x[1] for x in mu], color=COL[m], label=LAB[m], error_kw=dict(lw=0.5))
            cen = mean_r2(df, d, "CENTRAL", "central", t)[0]
            ax.axhline(cen, color="k", ls="--", lw=0.8)
            ax.set_xticks(range(len(scen)))
            if r == 1:
                ax.set_xticklabels(scen, rotation=45, ha="right", fontsize=7)
            if r == 0: ax.set_title(TNAME[t])
            if c == 0: ax.set_ylabel(f"{dn}\nTest R² (%)")
            lo = min(mean_r2(df, d, s, m, t)[0] for s in scen for m in methods)
            ax.set_ylim(max(0, lo - 8), None)
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=len(methods), frameon=False, fontsize=7.5, bbox_to_anchor=(0.5, 1.03))
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(os.path.join(FIG, "fig4_methods.png")); plt.close(fig)


def fig_budget(hists, methods, scen=("LS-dur-0.1", "BAND-dur")):
    fig, axs = plt.subplots(2, 2, figsize=(7.2, 4.8), sharex=True)
    for r, (d, dn) in enumerate(DS):
        for c, s in enumerate(scen):
            ax = axs[r, c]
            for m in methods:
                h = hists.get((d, s, m))
                if not h: continue
                pts = [(x["rnd"], np.mean([v[0] for v in x["test_r2"]])) for x in h if "test_r2" in x and x["rnd"] % 20 == 0]
                ax.plot(*zip(*pts), color=COL[m], label=LAB[m], marker="o", ms=2.5)
            ax.set_title(f"{dn}: {s}")
            if c == 0: ax.set_ylabel("Duration test R² (%)")
            if r == 1: ax.set_xlabel("Communication round")
    axs[0, 0].legend(frameon=False, fontsize=7)
    fig.savefig(os.path.join(FIG, "fig5_budget.png")); plt.close(fig)


if __name__ == "__main__":
    df, boots, quarters, hists, meta = load_all()
    fig_divergence(df, meta)
    fig_sweep(df)
    ms = [m for m in ["fedavg", "fedprox", "fedavgm", "fedadam", "fedtw", "fedtw_adam"] if (df.method == m).any()]
    fig_methods(df, ms, ["IID", "QTY", "TEMP", "LS-dur-1.0", "LS-dur-0.3", "LS-dur-0.1", "BAND-dur", "LS-cpu-0.1", "LS-mem-0.1"])
    fig_budget(hists, ms)
    print("figures written to", FIG)
