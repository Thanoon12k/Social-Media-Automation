"""Statistics, tables and figures from results/<trace>/*.json.

Outputs to ../results/analysis/: summary.csv, per_seed.csv, contrasts.csv, *.png
"""
import glob, json, os, sys
import numpy as np
import pandas as pd
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(HERE, "..", "results")
OUT = os.path.join(HERE, "..", "outputs", "analysis")
os.makedirs(OUT, exist_ok=True)
TARGETS = ["duration", "real_cpu_avg", "real_mem_avg"]
TNAME = {"duration": "Duration", "real_cpu_avg": "CPU", "real_mem_avg": "Memory"}


def load_all():
    rows, boots, quarters, hists, meta = [], {}, {}, {}, {}
    for f in sorted(glob.glob(os.path.join(RES, "alibaba", "*.json")) + glob.glob(os.path.join(RES, "in2p3", "*.json"))):
        r = json.load(open(f))
        key = (r["dataset"], r["scenario"], r["method"])
        meta[key] = dict(seconds=r["seconds"], divergence=r.get("divergence"), js=r.get("js"))
        hists[key] = r["hist"]
        for x in r["results"]:
            for t in TARGETS:
                m = x["metrics"][t]
                rows.append(dict(dataset=r["dataset"], scenario=r["scenario"], method=r["method"],
                                 seed=x["seed"], ckpt=x["ckpt"], best_round=x["best_round"],
                                 target=t, **m))
            if x["ckpt"] == "best":
                boots[key + (x["seed"],)] = np.array(x["boot"])
                quarters[key + (x["seed"],)] = np.array(x["quarters"])
    return pd.DataFrame(rows), boots, quarters, hists, meta


def ci_t(v):
    v = np.asarray(v, float)
    if len(v) < 2:
        return np.nan, np.nan
    h = stats.t.ppf(0.975, len(v) - 1) * v.std(ddof=1) / np.sqrt(len(v))
    return v.mean() - h, v.mean() + h


def holm(p):
    p = np.asarray(p, float)
    o = np.argsort(p)
    adj = np.empty_like(p)
    run = 0
    for i, j in enumerate(o):
        run = max(run, (len(p) - i) * p[j])
        adj[j] = min(1.0, run)
    return adj


def contrast(df, boots, a, b, scen_list, family, ckpt="best", datasets=("alibaba", "in2p3")):
    """paired (by seed) contrasts method a - method b for every trace x scenario x target"""
    out = []
    for d in datasets:
        for s in scen_list:
            for t in TARGETS:
                A = df[(df.dataset == d) & (df.scenario == s) & (df.method == a) & (df.ckpt == ckpt) & (df.target == t)].set_index("seed").R2
                B = df[(df.dataset == d) & (df.scenario == s) & (df.method == b) & (df.ckpt == ckpt) & (df.target == t)].set_index("seed").R2
                seeds = sorted(set(A.index) & set(B.index))
                if len(seeds) < 3:
                    continue
                dlt = (A[seeds] - B[seeds]).values
                w = stats.wilcoxon(dlt, zero_method="wilcox", alternative="two-sided") if np.any(dlt != 0) else None
                tt = stats.ttest_rel(A[seeds].values, B[seeds].values)
                # data-level uncertainty: block-bootstrap of the seed-averaged difference
                j = TARGETS.index(t)
                ba = np.mean([boots[(d, s, a, sd)][:, j] for sd in seeds], 0)
                bb = np.mean([boots[(d, s, b, sd)][:, j] for sd in seeds], 0)
                bd = ba - bb
                out.append(dict(family=family, dataset=d, scenario=s, target=t, a=a, b=b, n=len(seeds),
                                mean_a=A[seeds].mean(), mean_b=B[seeds].mean(), delta=dlt.mean(),
                                ci_lo=ci_t(dlt)[0], ci_hi=ci_t(dlt)[1],
                                boot_lo=np.percentile(bd, 2.5), boot_hi=np.percentile(bd, 97.5),
                                p_wilcoxon=w.pvalue if w else 1.0, p_t=tt.pvalue,
                                wins=int((dlt > 0).sum())))
    c = pd.DataFrame(out)
    if len(c):
        c["p_holm"] = holm(c.p_wilcoxon.values)
    return c


if __name__ == "__main__":
    df, boots, quarters, hists, meta = load_all()
    df.to_csv(os.path.join(OUT, "per_seed.csv"), index=False)
    g = df[df.ckpt == "best"].groupby(["dataset", "scenario", "method", "target"])
    summ = g.R2.agg(["mean", "std", "count"]).reset_index()
    summ["ci_lo"] = g.R2.apply(lambda v: ci_t(v)[0]).values
    summ["ci_hi"] = g.R2.apply(lambda v: ci_t(v)[1]).values
    summ["SMAPE"] = g.SMAPE.mean().values
    summ["R2_log"] = g.R2_log.mean().values
    summ["best_round"] = g.best_round.mean().values
    summ.to_csv(os.path.join(OUT, "summary.csv"), index=False)
    fin = df[df.ckpt == "final"].groupby(["dataset", "scenario", "method", "target"]).R2.mean().reset_index()
    fin.to_csv(os.path.join(OUT, "summary_final_round.csv"), index=False)
    json.dump({"|".join(k): v for k, v in meta.items()}, open(os.path.join(OUT, "meta.json"), "w"))
    print(summ.pivot_table(index=["dataset", "scenario", "method"], columns="target", values="mean").round(2).to_string())
