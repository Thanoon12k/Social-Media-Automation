#!/bin/bash
# Re-runs every training configuration of the paper (both traces in parallel,
# 2 CPU threads each). Configurations whose JSON already exists in ../results
# are skipped, so delete ../results/<trace>/ first to retrain from scratch.
# Wall time on 4 CPU cores: about 9-10 hours in total.
set -e
cd "$(dirname "$0")"
export FC_THREADS=${FC_THREADS:-2}
for d in alibaba in2p3; do
  ( python3 run_grid.py $d central core sweep prox abl rest central_long long \
      >> ../results/grid_$d.log 2>&1 ) &
done
wait
echo "all runs finished"
