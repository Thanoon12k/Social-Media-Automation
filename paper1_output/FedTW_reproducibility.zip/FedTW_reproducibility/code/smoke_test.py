"""Five-minute installation check: one seed, a few rounds, two methods, one regime.
Accuracies are low because training is very short; the test only checks that the
pipeline runs end to end and that FedTW and FedAvg coincide under IID clients."""
import time
import numpy as np
import fedcloud as fc

t0 = time.time()
ds = fc.load("alibaba")
print(f"Alibaba: {ds['N']:,} records | windows train/val/test = "
      f"{len(ds['Wtr']):,}/{len(ds['Wva']):,}/{len(ds['Wte']):,}")
assert ds["N"] == 191118, "unexpected Alibaba record count"
for scen in ["IID", "LS-dur-0.1"]:
    for name, cfg in [("FedAvg", dict(method="fedavg")), ("FedTW", dict(method="fedavg", iw=True))]:
        r = fc.run(ds, scen, [0], dict(cfg, rounds=5, eval_every=5))
        m = [x for x in r["results"] if x["ckpt"] == "best"][0]["metrics"]
        print(f"  {scen:11s} {name:7s} R2 dur/cpu/mem = "
              + "/".join(f"{m[t]['R2']:.1f}" for t in fc.TARGETS)
              + f"   JS(dur) = {np.mean(r['divergence'], 0)[0]:.3f}")
print(f"smoke test passed in {time.time() - t0:.0f}s")
