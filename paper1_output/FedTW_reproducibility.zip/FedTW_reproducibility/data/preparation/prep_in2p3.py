#!/usr/bin/env python3
"""
prep_in2p3.py — v28 CC-IN2P3 cleaning pipeline (official Zenodo source, scripted)

Produces dataset/cleaned_in2p3.csv from the OFFICIAL CC-IN2P3 2024 Workload Dataset.

  Source : Zenodo record 18668107  (DOI 10.5281/zenodo.18668107)
  Authors: Cochard, G. & Simon, B. (CC-IN2P3 / CNRS / LIG), CC-BY-4.0
  Paper  : arXiv:2606.05914
  Files  : 01.tsv.tar.gz .. 12.tsv.tar.gz  (one per month, ~885 MB total)

v28 changes vs. the hand-cleaned v27 file:
  * NO 0.1%/99.9% tail trimming (removed on purpose — all valid rows are kept)
  * every step is in this file, so `cleaned_in2p3.csv` is reproducible

Pipeline:
  monthly TSVs
    -> keep el9 == 0            (drop the corrupted section)
    -> duration      = end - start
    -> real_cpu_avg  = totalcpu / duration
    -> real_mem_avg  = maxrss
    -> drop NaN, keep duration > 0, real_cpu_avg > 0, real_mem_avg > 0
    -> sort by start_ts
    -> volume binning: mean of every CHUNK consecutive rows  (default 50)
    -> dataset/cleaned_in2p3.csv  [start_ts, duration, real_cpu_avg, real_mem_avg]

⚠ COLUMN NAMES: the exact TSV header was not verifiable without downloading the
   data. This script AUTO-DETECTS the five source fields from a list of common
   aliases and, if any is missing, prints the real header and exits so you can
   set them explicitly with --col-* flags. Run it once and it will tell you.

Usage (CLI):
    python prep_in2p3.py
    python prep_in2p3.py --chunk 50
    python prep_in2p3.py --months 1 2 3          # subset, for a quick smoke test
    python prep_in2p3.py --rawdir /path/to/tsvs  # skip download
    python prep_in2p3.py --col-start submit_time --col-end end_time ...

────────────────────────────────────────────────────────────────────────────
KAGGLE — run this script ALONE in its own notebook
────────────────────────────────────────────────────────────────────────────
  1. Notebook settings -> Internet: ON   (required for the Zenodo download)
  2. Accelerator: None
  3. Paste this whole file into one cell and append:

         main(["--outdir", "/kaggle/working/dataset", "--chunk", "50"])

     ...or as a Utility Script:
         !python prep_in2p3.py --outdir /kaggle/working/dataset --chunk 50

  4. FIRST RUN will likely stop with "could not map columns" and print the real
     TSV header. Copy the correct names into the --col-* flags and re-run.
     This is deliberate — guessing column names silently would corrupt the data.

  5. Output: /kaggle/working/dataset/cleaned_in2p3.csv

  Disk: ~885 MB download + ~4-6 GB extracted TSVs. Archives are deleted as they
  are extracted. Fits in Kaggle's ~20 GB /kaggle/working.
  Runtime: roughly 20-40 minutes.
────────────────────────────────────────────────────────────────────────────
"""

import argparse
import glob
import os
import shutil
import subprocess
import sys
import tarfile

import numpy as np
import pandas as pd

ZENODO_BASE = "https://zenodo.org/records/18668107/files"
KEEP = ['start_ts', 'duration', 'real_cpu_avg', 'real_mem_avg']

# candidate source-column names, in priority order
ALIASES = {
    'start':    ['start', 'start_time', 'starttime', 'start_ts', 'submit',
                 'submit_time', 'submittime', 'begin', 'begin_time'],
    'end':      ['end', 'end_time', 'endtime', 'end_ts', 'finish',
                 'finish_time', 'complete_time'],
    'totalcpu': ['totalcpu', 'total_cpu', 'cputime', 'cpu_time', 'usedcpu',
                 'cpu', 'totalcputime'],
    'maxrss':   ['maxrss', 'max_rss', 'maxmem', 'max_mem', 'memory',
                 'mem', 'rss', 'maxvmsize'],
    'el9':      ['el9', 'EL9', 'el_9', 'is_el9', 'os', 'osversion'],
}


def default_outdir() -> str:
    if os.environ.get('KAGGLE_KERNEL_RUN_TYPE') or os.path.exists('/kaggle/working'):
        return '/kaggle/working/dataset'
    if os.path.exists('/content'):
        return '/content/dataset'
    return 'dataset'


# ─── download & extract ───────────────────────────────────────────────────────
def fetch_months(rawdir: str, months) -> list:
    """Download + extract each monthly archive. Returns the list of TSV paths."""
    os.makedirs(rawdir, exist_ok=True)

    free_gb = shutil.disk_usage(rawdir).free / 1e9
    print(f"[in2p3] free disk at {rawdir}: {free_gb:.1f} GB")
    if free_gb < 8:
        sys.exit("[in2p3] FATAL: need ~8 GB free for download + extraction.")

    for m in months:
        tag = f"{m:02d}"
        marker = os.path.join(rawdir, f".done_{tag}")
        if os.path.exists(marker):
            print(f"[in2p3] month {tag}: already extracted")
            continue

        arch = os.path.join(rawdir, f"{tag}.tsv.tar.gz")
        url = f"{ZENODO_BASE}/{tag}.tsv.tar.gz?download=1"

        if not os.path.exists(arch):
            print(f"[in2p3] month {tag}: downloading …")
            subprocess.run(
                f'wget -q -c -O "{arch}" "{url}"',
                shell=True, check=True)

        print(f"[in2p3] month {tag}: extracting …")
        with tarfile.open(arch, 'r:gz') as tf:
            tf.extractall(rawdir)
        os.remove(arch)                      # free disk immediately
        open(marker, 'w').close()

    tsvs = sorted(glob.glob(os.path.join(rawdir, '**', '*.tsv'), recursive=True))
    if not tsvs:
        sys.exit(f"[in2p3] FATAL: no .tsv files found under {rawdir}")
    print(f"[in2p3] {len(tsvs)} TSV file(s) ready")
    return tsvs


# ─── column mapping ───────────────────────────────────────────────────────────
def map_columns(header, overrides):
    """Resolve the five needed source fields against the real TSV header."""
    lower = {c.lower().strip(): c for c in header}
    resolved, missing = {}, []

    for key, cands in ALIASES.items():
        if overrides.get(key):
            name = overrides[key]
            if name not in header:
                sys.exit(f"[in2p3] FATAL: --col-{key} '{name}' is not in the header.")
            resolved[key] = name
            continue
        hit = next((lower[c.lower()] for c in cands if c.lower() in lower), None)
        if hit:
            resolved[key] = hit
        else:
            missing.append(key)

    if missing:
        print("\n" + "=" * 70)
        print("[in2p3] COULD NOT MAP THESE COLUMNS:", ", ".join(missing))
        print("[in2p3] Actual TSV header:")
        for c in header:
            print("   ", c)
        print("\n[in2p3] Re-run with explicit flags, e.g.:")
        print("    --col-start START --col-end END --col-totalcpu TOTALCPU "
              "--col-maxrss MAXRSS --col-el9 EL9")
        print("=" * 70)
        sys.exit(1)

    print("[in2p3] column mapping:")
    for k, v in resolved.items():
        print(f"    {k:<9} -> {v}")
    return resolved


# ─── cleaning ─────────────────────────────────────────────────────────────────
def clean(tsvs, overrides, keep_el9_zero=True) -> pd.DataFrame:
    head = pd.read_csv(tsvs[0], sep='\t', nrows=5)
    cols = map_columns(list(head.columns), overrides)
    usecols = list(dict.fromkeys(cols.values()))

    frames, n_raw = [], 0
    stats = dict(el9=0, nan=0, nonpos=0)

    for i, path in enumerate(tsvs, 1):
        df = pd.read_csv(path, sep='\t', usecols=usecols, low_memory=False)
        n_raw += len(df)
        n0 = len(df)

        if keep_el9_zero:
            el9 = pd.to_numeric(df[cols['el9']], errors='coerce')
            df = df[el9 == 0]
            stats['el9'] += n0 - len(df)
        n0 = len(df)

        out = pd.DataFrame({
            'start_ts': pd.to_numeric(df[cols['start']], errors='coerce'),
        })
        end = pd.to_numeric(df[cols['end']], errors='coerce')
        tcpu = pd.to_numeric(df[cols['totalcpu']], errors='coerce')
        out['duration'] = end - out['start_ts']
        out['real_cpu_avg'] = tcpu / out['duration']
        out['real_mem_avg'] = pd.to_numeric(df[cols['maxrss']], errors='coerce')

        out = out.replace([np.inf, -np.inf], np.nan).dropna(subset=KEEP)
        stats['nan'] += n0 - len(out); n0 = len(out)

        out = out[(out['duration'] > 0) &
                  (out['real_cpu_avg'] > 0) &
                  (out['real_mem_avg'] > 0)]
        stats['nonpos'] += n0 - len(out)

        # NOTE (v28): no 0.1%/99.9% tail trimming here, by design.

        if len(out):
            frames.append(out[KEEP])
        print(f"\r[in2p3] file {i}/{len(tsvs)} | raw {n_raw:,} | "
              f"kept {sum(map(len, frames)):,}", end="", flush=True)

    print()
    if not frames:
        sys.exit("[in2p3] FATAL: no rows survived filtering.")

    res = pd.concat(frames, ignore_index=True)
    print(f"[in2p3] raw rows            : {n_raw:,}")
    print(f"[in2p3]   dropped el9 != 0    : {stats['el9']:,}")
    print(f"[in2p3]   dropped NaN/inf     : {stats['nan']:,}")
    print(f"[in2p3]   dropped non-positive: {stats['nonpos']:,}")
    print(f"[in2p3] surviving rows      : {len(res):,}")
    return res


def chunk_average(df: pd.DataFrame, chunk: int) -> pd.DataFrame:
    df = df.sort_values('start_ts').reset_index(drop=True)
    if chunk <= 1:
        return df[KEEP]
    return df.groupby(df.index // chunk)[KEEP].mean().reset_index(drop=True)


def main(argv=None):
    """argv=None -> read sys.argv (CLI). Pass a list to call from a notebook cell."""
    ap = argparse.ArgumentParser()
    ap.add_argument('--outdir', default=default_outdir())
    ap.add_argument('--rawdir', default=None,
                    help='where TSVs live / are extracted (default: <outdir>/in2p3_raw)')
    ap.add_argument('--chunk', type=int, default=50,
                    help='volume-binning chunk size (default: 50)')
    ap.add_argument('--months', type=int, nargs='*', default=list(range(1, 13)),
                    help='which months to use (default: all 12)')
    ap.add_argument('--no-el9-filter', action='store_true',
                    help='skip the el9 == 0 filter')
    for k in ALIASES:
        ap.add_argument(f'--col-{k}', default=None,
                        help=f'explicit source column for {k}')
    args = ap.parse_args(argv)

    os.makedirs(args.outdir, exist_ok=True)
    rawdir = args.rawdir or os.path.join(args.outdir, 'in2p3_raw')

    existing = sorted(glob.glob(os.path.join(rawdir, '**', '*.tsv'), recursive=True))
    tsvs = existing if existing else fetch_months(rawdir, args.months)
    if existing:
        print(f"[in2p3] using {len(existing)} already-extracted TSV(s) in {rawdir}")

    overrides = {k: getattr(args, f'col_{k}') for k in ALIASES}
    df = clean(tsvs, overrides, keep_el9_zero=not args.no_el9_filter)
    out = chunk_average(df, args.chunk)

    dest = os.path.join(args.outdir, 'cleaned_in2p3.csv')
    out.to_csv(dest, index=False)

    print()
    print("=" * 66)
    print(f"[in2p3] chunk size          : {args.chunk}")
    print(f"[in2p3] FINAL ROWS          : {len(out):,}")
    print(f"[in2p3] written             : {dest}")
    print(f"[in2p3] columns             : {list(out.columns)}")
    print(f"[in2p3] start_ts range      : {out.start_ts.min():.0f} .. {out.start_ts.max():.0f}")
    print(f"[in2p3] duration  med/p99   : {out.duration.median():.2f} / "
          f"{np.percentile(out.duration, 99):.2f}")
    print("=" * 66)

    if not (150_000 <= len(out) <= 300_000):
        print(f"[in2p3] WARNING: {len(out):,} rows is outside your 150k-300k target. "
              f"Adjust --chunk (higher chunk -> fewer rows).")
        approx = len(df) / 225_000
        print(f"[in2p3] hint: chunk ≈ {approx:.0f} would land near 225k rows.")
    else:
        print("[in2p3] OK: row count is inside the 150k-300k target window.")


if __name__ == '__main__':
    main(["--outdir", "/kaggle/working/dataset", "--chunk", "50"])