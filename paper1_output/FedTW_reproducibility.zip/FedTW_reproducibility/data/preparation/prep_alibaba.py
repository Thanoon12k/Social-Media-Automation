#!/usr/bin/env python3
"""
prep_alibaba.py — v28 Alibaba cleaning pipeline (official source, scripted, reproducible)

Produces dataset/cleaned_alibaba.csv from the OFFICIAL Alibaba Cluster Trace 2017 tarball.

v28 changes vs. the hand-cleaned v27 file:
  * NO 0.1%/99.9% tail trimming (removed on purpose — all valid rows are kept)
  * real_mem_avg > 0 filter added (v27 filtered duration and cpu only, not memory)
  * every step is in this file, so `cleaned_alibaba.csv` is reproducible with one command

Pipeline:
  official batch_instance.csv
    -> keep start_ts > 0
    -> duration = end_ts - start_ts
    -> keep status == 'Terminated'
    -> drop NaN in (duration, real_cpu_avg, real_mem_avg)
    -> keep duration > 0, real_cpu_avg > 0, real_mem_avg > 0
    -> sort by start_ts
    -> volume binning: mean of every CHUNK consecutive rows
    -> dataset/cleaned_alibaba.csv  [start_ts, duration, real_cpu_avg, real_mem_avg]

Usage (CLI):
    python prep_alibaba.py                      # download + clean
    python prep_alibaba.py --chunk 10           # explicit chunk size (default 10)
    python prep_alibaba.py --raw /path/to/batch_instance.csv   # skip download
    python prep_alibaba.py --outdir dataset

────────────────────────────────────────────────────────────────────────────
KAGGLE — run this script ALONE in its own notebook
────────────────────────────────────────────────────────────────────────────
  1. Notebook settings -> Internet: ON   (required for the download)
  2. Accelerator: None  (this is pure pandas — a GPU is wasted here)
  3. Paste this whole file into one cell and append:

         main(["--outdir", "/kaggle/working/dataset", "--chunk", "10"])

     ...or save it as a Kaggle Dataset/Utility Script and call:

         !python prep_alibaba.py --outdir /kaggle/working/dataset --chunk 10

  4. Output: /kaggle/working/dataset/cleaned_alibaba.csv
     Save the notebook so the output persists, then attach it as a Kaggle
     Dataset input for the training notebook.

  Disk: the tarball is ~858 MB and is deleted after extraction. Kaggle gives
  ~20 GB of /kaggle/working, which is comfortably enough.
  Runtime: expect roughly 15-30 minutes, mostly download + streaming parse.
────────────────────────────────────────────────────────────────────────────
"""

import argparse
import os
import shutil
import subprocess
import sys

import numpy as np
import pandas as pd


def default_outdir() -> str:
    """Kaggle-aware default output directory."""
    if os.environ.get('KAGGLE_KERNEL_RUN_TYPE') or os.path.exists('/kaggle/working'):
        return '/kaggle/working/dataset'
    if os.path.exists('/content'):          # Colab
        return '/content/dataset'
    return 'dataset'

# ─── constants ────────────────────────────────────────────────────────────────
TRACE_URL = ("http://aliopentrace.oss-cn-beijing.aliyuncs.com/"
             "v2017Traces/alibaba-trace-2017.tar.gz")
TARBALL = "alibaba-trace-2017.tar.gz"
RAW_NAME = "batch_instance.csv"

# batch_instance.csv ships without a header row
RAW_COLS = ['start_ts', 'end_ts', 'job_id', 'task_id', 'machine_id', 'status',
            'seq', 'total_seq', 'real_cpu_max', 'real_cpu_avg',
            'real_mem_max', 'real_mem_avg']

KEEP = ['start_ts', 'duration', 'real_cpu_avg', 'real_mem_avg']
READ_CHUNK = 2_000_000     # rows per streaming chunk


def fetch_raw(outdir: str) -> str:
    """Download + extract the official tarball if batch_instance.csv is absent."""
    raw = os.path.join(outdir, RAW_NAME)
    if os.path.exists(raw):
        print(f"[alibaba] raw already present: {raw}")
        return raw

    # Kaggle: a raw copy may already be attached as an input dataset
    for pat in ('/kaggle/input/**/batch_instance.csv',):
        import glob
        hits = glob.glob(pat, recursive=True)
        if hits:
            print(f"[alibaba] found attached Kaggle input: {hits[0]}")
            return hits[0]

    free_gb = shutil.disk_usage(outdir).free / 1e9
    print(f"[alibaba] free disk at {outdir}: {free_gb:.1f} GB")
    if free_gb < 6:
        sys.exit("[alibaba] FATAL: need ~6 GB free for download + extraction.")

    print(f"[alibaba] downloading official trace -> {TRACE_URL}")
    print("[alibaba] this is ~858 MB compressed; it will take a while.")
    cmd = (
        f'cd "{outdir}" && '
        f'wget -q -c {TRACE_URL} && '

        f"tar -xzf {TARBALL} --wildcards '*{RAW_NAME}' --strip-components=1 && "
        f'rm -f {TARBALL}'
    )
    subprocess.run(cmd, shell=True, check=True)

    if not os.path.exists(raw):
        sys.exit(f"[alibaba] FATAL: extraction finished but {raw} not found.")
    print(f"[alibaba] extracted: {raw}")
    return raw


def clean(raw_path: str) -> pd.DataFrame:
    """Stream the raw CSV, apply the v28 filters, return the concatenated frame."""
    kept, n_raw = [], 0
    stats = dict(nonpos_start=0, not_terminated=0, nan_rows=0, nonpos_metric=0)

    reader = pd.read_csv(raw_path, header=None, names=RAW_COLS,
                         chunksize=READ_CHUNK, low_memory=False)

    for i, df in enumerate(reader, 1):
        n_raw += len(df)
        n0 = len(df)

        df = df[df['start_ts'] > 0]
        stats['nonpos_start'] += n0 - len(df); n0 = len(df)

        df = df[df['status'] == 'Terminated']
        stats['not_terminated'] += n0 - len(df); n0 = len(df)

        df = df.copy()
        df['duration'] = df['end_ts'] - df['start_ts']

        df = df.dropna(subset=['duration', 'real_cpu_avg', 'real_mem_avg'])
        stats['nan_rows'] += n0 - len(df); n0 = len(df)

        # v28: memory is filtered too (v27 checked duration + cpu only)
        df = df[(df['duration'] > 0) &
                (df['real_cpu_avg'] > 0) &
                (df['real_mem_avg'] > 0)]
        stats['nonpos_metric'] += n0 - len(df)

        # NOTE (v28): no 0.1%/99.9% tail trimming here, by design.

        if len(df):
            kept.append(df[KEEP])

        print(f"\r[alibaba] streamed {n_raw:,} raw rows | kept {sum(map(len, kept)):,}",
              end="", flush=True)

    print()
    if not kept:
        sys.exit("[alibaba] FATAL: no rows survived filtering — check the raw file.")

    out = pd.concat(kept, ignore_index=True)
    print(f"[alibaba] raw rows           : {n_raw:,}")
    print(f"[alibaba]   dropped start_ts<=0 : {stats['nonpos_start']:,}")
    print(f"[alibaba]   dropped non-Terminated: {stats['not_terminated']:,}")
    print(f"[alibaba]   dropped NaN         : {stats['nan_rows']:,}")
    print(f"[alibaba]   dropped non-positive: {stats['nonpos_metric']:,}")
    print(f"[alibaba] surviving rows     : {len(out):,}")
    return out


def chunk_average(df: pd.DataFrame, chunk: int) -> pd.DataFrame:
    """Sort chronologically, then take the mean of every `chunk` consecutive rows."""
    df = df.sort_values('start_ts').reset_index(drop=True)
    if chunk <= 1:
        return df[KEEP]
    grp = df.index // chunk
    out = df.groupby(grp)[KEEP].mean().reset_index(drop=True)
    return out


def main(argv=None):
    """argv=None -> read sys.argv (CLI). Pass a list to call from a notebook cell."""
    ap = argparse.ArgumentParser()
    ap.add_argument('--outdir', default=default_outdir(),
                    help='where cleaned_alibaba.csv is written')
    ap.add_argument('--raw', default=None,
                    help='path to an existing batch_instance.csv (skips download)')
    ap.add_argument('--chunk', type=int, default=10,
                    help='volume-binning chunk size (default: 10)')
    args = ap.parse_args(argv)

    os.makedirs(args.outdir, exist_ok=True)
    raw_path = args.raw or fetch_raw(args.outdir)

    df = clean(raw_path)
    out = chunk_average(df, args.chunk)

    dest = os.path.join(args.outdir, 'cleaned_alibaba.csv')
    out.to_csv(dest, index=False)

    print()
    print("=" * 66)
    print(f"[alibaba] chunk size         : {args.chunk}")
    print(f"[alibaba] FINAL ROWS         : {len(out):,}")
    print(f"[alibaba] written            : {dest}")
    print(f"[alibaba] columns            : {list(out.columns)}")
    print(f"[alibaba] start_ts range     : {out.start_ts.min():.0f} .. {out.start_ts.max():.0f}")
    print(f"[alibaba] duration  med/p99  : {out.duration.median():.2f} / "
          f"{np.percentile(out.duration, 99):.2f}")
    print("=" * 66)

    if not (150_000 <= len(out) <= 300_000):
        print(f"[alibaba] WARNING: {len(out):,} rows is outside your 150k-300k target. "
              f"Adjust --chunk (higher chunk -> fewer rows).")
    else:
        print("[alibaba] OK: row count is inside the 150k-300k target window.")




if __name__ == '__main__':
    main(["--outdir", "/kaggle/working/dataset", "--chunk", "10"])