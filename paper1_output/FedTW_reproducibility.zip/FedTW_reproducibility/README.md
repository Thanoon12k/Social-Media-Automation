# Reproducibility package

**FedTW: target-wise label-shift correction for federated multi-target cloud workload forecasting under heterogeneous clients**
Thanoon Y. Mohammed, Ahmad F. AL-allaf, M. R. Mouhamed

This package contains the data, the code and the per-seed results behind every
number, table and figure in the paper. Everything runs on CPU.

## Contents

```
README.md               this file
requirements.txt        exact package versions used for the paper
data/
  cleaned_alibaba_10.csv    Alibaba cluster-trace-v2017, 191,118 records (blocks of 10 jobs)
  cleaned_in2p3_70.csv      CC-IN2P3 2024 workload dataset, 343,368 records (blocks of 70 jobs)
  SHA256SUMS                checksums of the two files
  preparation/              scripts that rebuild the two files from the official raw traces
code/
  fedcloud.py           data protocol, client regimes, LSTM model, FedAvg / FedProx /
                        FedAvgM / FedAdam / FedTW, evaluation, bootstrap, temporal blocks
  run_grid.py           the complete experiment grid (every configuration in the paper)
  methods.json          hyper-parameters of the compared methods
  run_experiments.sh    retrains everything (about 9-10 h on 4 CPU cores)
  make_outputs.sh       statistics, tables and figures from results/ (about 1 min)
  analyze.py, make_numbers.py, figures.py, fig1_schematic.py, export_tables.py
  smoke_test.py         2-minute installation check
  verify_rerun.py       retrains one configuration and compares it with results/
results/
  alibaba/*.json, in2p3/*.json   one file per (regime, method): per-seed test metrics,
                                 per-round validation and test history, block-bootstrap
                                 and temporal-block R², client divergence, run time
outputs/                created by make_outputs.sh (already filled in this package)
  Table1_scen.csv ... Table6_abl.csv   the six tables of the paper
  figures/fig1-fig5                    the five figures of the paper
  analysis/per_seed.csv                every test metric of every seed and checkpoint
  analysis/contrasts.csv               all paired tests (Wilcoxon, Holm, CIs, bootstrap)
  numbers.json                         every number quoted in the text
```

## 1. Install (Python 3.11)

```bash
pip install torch==2.14.0 --index-url https://download.pytorch.org/whl/cpu
pip install numpy==2.4.6 pandas==3.0.6 scipy==1.17.1 matplotlib==3.11.2
cd code
python3 smoke_test.py          # about 2 minutes
```

## 2. Reproduce the tables and figures from the stored results (no training)

```bash
cd code
./make_outputs.sh
```
This rewrites `outputs/` from `results/`. The numbers are identical to those in the paper.

## 3. Check that retraining gives the same results

```bash
cd code
python3 verify_rerun.py                              # alibaba, LS-dur-0.1, FedTW (about 5 min)
python3 verify_rerun.py in2p3 BAND-dur fedavg        # any other configuration
```
On our machine, retraining reproduced the stored per-seed R² values exactly (difference 0.0000 points).
A different CPU or library version can introduce differences in the last decimals.

## 4. Retrain the whole study

```bash
cd code
rm -rf ../results/alibaba ../results/in2p3        # otherwise finished configurations are skipped
mkdir -p ../results/alibaba ../results/in2p3
./run_experiments.sh                              # about 9-10 h on 4 CPU cores
./make_outputs.sh
```
A single trace or group can be run with, for example, `python3 run_grid.py alibaba core`.
The groups are `central`, `core`, `sweep`, `prox`, `abl`, `rest`, `central_long` and `long`. The group
`prox` needs `sweep` first, because it uses the coefficient selected on validation data.

## Experimental protocol (as implemented in `fedcloud.py`)

| Item | Setting |
|---|---|
| Split | chronological 72% train / 8% validation / 20% test, made before any client partitioning |
| Samples | 24 consecutive records → next record (duration, CPU, memory); windows never cross a split boundary |
| Scaling | log(1+x), then median / inter-quartile range fitted on the training period only |
| Model | LSTM(32) encoder, dropout 0.2, one 16-unit ReLU head per target; MAE loss |
| Federation | 20 clients, 60 rounds, 25 local Adam steps (lr 1e-3, batch 32), sample-weighted aggregation |
| Selection | checkpoint with the lowest validation MAE (checked every 5 rounds); test set used only for reporting |
| Seeds | 0–9 (5 seeds for the μ sweep, ablations and 180-round runs); a seed fixes the initialisation, the partition and the mini-batches |
| Regimes | IID, QTY, TEMP, SYS, PART, LS-dur-1.0/0.3/0.1, BAND-dur, LS-cpu-0.1, LS-mem-0.1 (`SCENARIOS` in `fedcloud.py`) |
| FedTW | per-target weights min(p/π_k, 10) from 10 training-quantile bins, Laplace smoothing 1, renormalised per client |

## Rebuilding the data files from the raw traces (optional)

The two CSV files in `data/` are the inputs of every experiment. To rebuild them from the official sources:
```bash
python3 data/preparation/prep_alibaba.py --chunk 10 --outdir data   # Alibaba cluster-trace-v2017 batch_instance
python3 data/preparation/prep_in2p3.py  --chunk 70 --outdir data    # CC-IN2P3 2024 workload dataset (Zenodo)
```
Then rename the outputs to `cleaned_alibaba_10.csv` and `cleaned_in2p3_70.csv`, and compare them with
`data/SHA256SUMS`. Sources: https://github.com/alibaba/clusterdata (cluster-trace-v2017) and
https://doi.org/10.5281/zenodo.18668107.

## Licence and citation

The derived data files are redistributed under the terms of the original traces. Please cite the
paper and the two trace providers when using this package.
